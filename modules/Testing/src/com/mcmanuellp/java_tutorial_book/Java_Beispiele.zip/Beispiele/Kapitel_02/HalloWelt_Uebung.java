 
class 
HalloWelt_Uebung
{
public static void main(String[]args) {
System.out.println("Es gibt nur ein Glueck: die Pflicht");
System.out.println("nur einen Trost: die Arbeit"); System.out.println( 
"nur einen Genuss: das Schoene");
}
}
