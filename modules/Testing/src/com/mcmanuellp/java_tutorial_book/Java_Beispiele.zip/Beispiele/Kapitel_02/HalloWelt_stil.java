// HalloWelt_stil.java 
class HalloWelt_stil{public 
static void main(String[] 
args){System.out.println("Hallo Welt!");}}
