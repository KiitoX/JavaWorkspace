import java.lang.String;
import java.lang.System;
import java.lang.Math;

class Import
{
   public static void main(String[] args)
   {
      String gruss = "Hallo Welt!";
      System.out.println(gruss);
      
      System.out.println("Sinus von PI: " + Math.sin(3.141592));
      
      java.util.Date datum = new java.util.Date();
      System.out.println(datum);
   }
}
