/* Dies ist der zu verbessernde Code */

/*
import java.lang.*;

class Import_Uebung
{
   public static void main(String[] args)
   {
      Date datum = new Date();
      System.out.println(sin(3.141592));
   }
}
*/




/* Dies ist der verbesserte Code */

import java.util.Date;

class Import_Uebung
{
   public static void main(String[] args)
   {
      Date datum = new Date();
      System.out.println(Math.sin(3.141592));
   }
}


