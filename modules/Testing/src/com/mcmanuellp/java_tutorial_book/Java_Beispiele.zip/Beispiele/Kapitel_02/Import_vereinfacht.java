import java.util.*;
import java.lang.*;
import static java.lang.Math.*;

class Import_vereinfacht
{
   public static void main(String[] args)
   {
      String gruss = "Hallo Welt!";
      System.out.println(gruss);
      
      System.out.println("Sinus von PI: " + sin(3.141592));
      
      Date datum = new Date();
      System.out.println(datum);
      
      Vector container = new Vector();
   }
}
