class Konstanten
{                             
   public static void main(String[] args)                   
   {           
      final double GRAVITATION = 6.67e-11; // die Gravitationskonstante
      
      double masse1 = 1e9;             // Masse des 1. K�rpers
      double masse2 = 1e3;             // Masse des 2. K�rpers
      double distanz = 1e4;            // Abstand
      double g;                        // Gravitationskraft

      g = GRAVITATION * (masse1 * masse2) / (distanz * distanz);
      
      System.out.println(" Kraft : " + g);
   }
}
