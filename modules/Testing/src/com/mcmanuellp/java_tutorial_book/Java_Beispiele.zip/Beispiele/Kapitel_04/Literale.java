public class Literale
{
   public static void main(String[] args)
   {
      int alter = 25;
      double preis = 1190;
      boolean volljaehrig = true;
      char antwort = 'j';
      String vorname = "K�nigin Elisabeth";
      String gedicht =   "Belsatzar \n"
                       + "\n"
                       + "Die Mitternach zog naeher schon \n"
                       + "In stummer Ruh lag Babylon. \n";
                       
      System.out.println(gedicht);
      
      double mwst;  
      mwst = preis - (preis / 1.19);
      
      System.out.println(" Preis: " + preis);
      System.out.println(" Enthaltene Mehrwertsteuer: " + mwst);
   }
}
