import java.io.*;

class Strings_a
{
   public static void main(String[] args)                   
   {                            
      String komponist = "Edvard Grieg";

      System.out.println("Dies ist ein String-Literal.");
      System.out.println("Norwegischer Komponent : " + komponist);
      
      System.out.println("Diese blöden Umlaute!");
      System.out.println("Diese bloeden Umlaute!");
   }
}
