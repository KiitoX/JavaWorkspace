import java.util.Scanner;

public class Strings_b
{
   public static void main(String[] args)                   
   {                            
      String vorname = "";
      String nachname = "";

      System.out.print(" Geben Sie Ihren (ersten) Vornamen ein: ");
      Scanner sc = new Scanner(System.in);
      vorname = sc.next();  

      System.out.print(" Geben Sie Ihren Nachnamen ein        : ");
      nachname = sc.next();  
      
      System.out.println();
      System.out.println(" Hallo " + vorname + " " + nachname + "!");
   }
}
