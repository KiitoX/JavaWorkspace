import java.lang.*;

public class Uebung_Compilierfehler
{
   public static void main(String[] args)                   
   {                            
      name = "Magda";
      String name;

      System.out.println(" Hallo " + name + "!");
   }
}
