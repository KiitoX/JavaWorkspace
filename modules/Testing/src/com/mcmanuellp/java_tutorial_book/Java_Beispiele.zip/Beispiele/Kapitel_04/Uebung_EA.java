import java.util.Scanner;

public class Uebung_EA
{
   public static void main(String[] args)                   
   {                            
      String vorname;
      
      System.out.print(" Geben Sie Ihren Vornamen ein: ");
      Scanner sc = new Scanner(System.in);
      vorname = sc.next();  

      System.out.println();
      System.out.println(" Hallo " + vorname 
                       + ", freut mich dich zu sehen!");
   }
}
