class Variablendefinition
{
   public static void main(String[] args)
   {
      int eineZahl = 5, nochEineZahl;
      
      System.out.println(" Wert von eineZahl: " + eineZahl);
      //System.out.println(" Wert von nochEineZahl: " + nochEineZahl);
      
      nochEineZahl = 2;
      eineZahl = eineZahl * nochEineZahl + 10;
      
      System.out.println(" Wert von eineZahl: " + eineZahl);
      System.out.println(" Wert von nochEineZahl: " + nochEineZahl);
   }
}
