class Zahlen_a
{
   public static void main(String[] args)                   
   {                    
      int alter = 25;
      double quote1 = 0.123456789;
      double quote2 = 12345.6789;
      double quote3 = 12345678.0;

      System.out.println("Literal: " + 3);
      System.out.println("Alter  : " + alter);
      System.out.println("Quote  : " + quote1);
      System.out.println("Quote  : " + quote2);
      System.out.println("Quote  : " + quote3);
   }
}
