import java.util.Scanner;

public class Zahlen_b
{
   public static void main(String[] args)                   
   {     
      String name;
      int alter;
      
      System.out.print(" Geben Sie Ihren Nachnamen ein: ");
      Scanner sc = new Scanner(System.in);
      name = sc.next();  

      System.out.print(" Geben Sie Ihr Alter ein      : ");
      alter = sc.nextInt();
      
      System.out.println(); 
      System.out.println(" " + name + " ist " + alter + " Jahre alt.");
   }
}