import java.util.Scanner;

class Bit
{
   public static void main(String[] args)                   
   {  
      int zahl = 0;

      System.out.println();
      System.out.print(" Geben Sie eine ganze Zahl ein: ");
      Scanner sc = new Scanner(System.in);
      zahl = sc.nextInt();  

      if ((zahl & 1) == 0) 
         System.out.println(" Die Zahl ist gerade ");
      else
         System.out.println(" Die Zahl ist ungerade ");

      if ((zahl % 2) == 0) 
         System.out.println(" Die Zahl ist gerade ");
      else
         System.out.println(" Die Zahl ist ungerade ");
   }
}
