import java.util.Scanner;

class Boolean
{
   public static void main(String[] args)                   
   {  
      boolean erg1;
      boolean erg2;
      boolean erg3;
      
      erg1 = 10 < 5;             // erg1 wird zu false
      System.out.println(erg1);
      erg2 = 10 > 5;             // erg1 wird zu true
      System.out.println(erg2);

      System.out.println();
      
      erg3 = !erg1;              // logisches Nicht, erg3 wird zu true
      System.out.println(erg3);
      erg3 = erg1 && erg2;       // logisches Und, erg3 wird zu false
      System.out.println(erg3);
      erg3 = erg1 || erg2;       // logisches Oder, erg3 wird zu true
      System.out.println(erg3);

      System.out.println();
      
      boolean option;
      System.out.print(" Geben Sie true oder false ein: ");
      Scanner sc = new Scanner(System.in);
      option = sc.nextBoolean();  
      System.out.println(option);
   }
}
