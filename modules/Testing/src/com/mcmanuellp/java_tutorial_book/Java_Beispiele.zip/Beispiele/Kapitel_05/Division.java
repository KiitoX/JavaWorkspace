class Division
{
   public static void main(String[] args)                   
   {  
      int ergInt;
      double ergDouble;
      
      ergInt = 10 / 3;                  // reine Int-Division: ergInt wird zu 3
      System.out.println(ergInt);

      System.out.println();
      ergDouble = 10.0 / 3.0;           // reine Double-Division: ergDouble wird zu 3.333
      System.out.println(ergDouble);

      System.out.println();
      ergDouble = 10 / 3.0;             // gemischte Division: ergDouble wird zu 3.333
      System.out.println(ergDouble);

      System.out.println();
      ergInt = (int) (10 / 3.0);        // gemischte Division: ergInt wird zu 3; Fehler ohne Cast
      System.out.println(ergInt);
   }
}
