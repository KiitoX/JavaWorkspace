import java.util.Scanner;

class Ganzzahlen
{
   public static void main(String[] args)                   
   {  
      int z1 = 10;
      int z2 =  3;
      int erg;
      
      // arithmetische Operatoren
      System.out.println();
      System.out.println(" arithmetische Operatoren ");
      erg = z1 + z2;        // Addition: erg wird zu 13
      System.out.println(erg);
      erg = z1 - z2;        // Subtraktion: erg wird zu 7
      System.out.println(erg);
      erg = z1 * z2;        // Multiplikation: erg wird zu 30
      System.out.println(erg);
      erg = z1 / z2;        // Division: erg wird zu 3
      System.out.println(erg);
      erg = z1 % z2;        // Modulo: erg wird zu 1
      System.out.println(erg);
      
      // Inkrement und Dekrement
      System.out.println();
      System.out.println(" Inkrement und Dekrement ");
      erg = z1++;           // z1 wird zu 11, erg zu 10 (alter Wert von z1)
      System.out.println(z1 + ", " + erg);
      erg = ++z1;           // z1 wird zu 12, erg zu 12 (neuer Wert von z1)
      System.out.println(z1 + ", " + erg);
      --z1;                 // z1 wird zu 11;
      System.out.println(z1);
      z1--;                 // z1 wird zu 10;
      System.out.println(z1);
      
      // Vergleiche
      System.out.println();
      System.out.println(" Vergleiche ");
      boolean testerg;
      testerg = (z1 == z2);       // Gleich: testerg wird zu false
      System.out.println(testerg);
      testerg = (z1 != z2);       // Ungleich: testerg wird zu true
      System.out.println(testerg);
      testerg = (z1 > z2);        // Gr��er: testerg wird zu true
      System.out.println(testerg);
      testerg = (z1 >= z2);       // Gr��er oder gleich: testerg wird zu true
      System.out.println(testerg);
      testerg = (z1 < z2);        // Kleiner: testerg wird zu false
      System.out.println(testerg);
      testerg = (z1 <= z2);       // Kleiner oder gleich: testerg wird zu false
      System.out.println(testerg);
      
      // Ein- und Ausgabe
      System.out.println();
      System.out.println(" Ein- und Ausgabe ");
      System.out.print(" Geben Sie eine ganze Zahl ein: ");
      Scanner sc = new Scanner(System.in);
      z1 = sc.nextInt();           
      System.out.println(z1); 
      
   }
}
