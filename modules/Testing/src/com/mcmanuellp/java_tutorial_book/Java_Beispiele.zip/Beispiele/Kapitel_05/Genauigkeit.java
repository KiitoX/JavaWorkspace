class Genauigkeit
{
   public static void main(String[] args)                   
   {  
      int iVar = 1222333444;
      System.out.println(" iVar vor Zwischenspeicherung in fVar:  " + iVar);
      float fVar = iVar;
      iVar = (int) fVar;
      System.out.println(" iVar nach Zwischenspeicherung in fVar: " + iVar);
   }
}
