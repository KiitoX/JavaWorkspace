import java.util.Scanner;

class Gleitkomma
{
   public static void main(String[] args)                   
   {  
      double z1 = 10.2;
      double z2 =  3.0;
      double erg;
      
      // arithmetische Operatoren
      System.out.println();
      System.out.println(" arithmetische Operatoren ");
      erg = z1 + z2;        // Addition: erg wird zu 13.2
      System.out.println(erg);
      erg = z1 - z2;        // Subtraktion: erg wird zu 7.199999
      System.out.println(erg);
      erg = z1 * z2;        // Multiplikation: erg wird zu 30.59999
      System.out.println(erg);
      erg = z1 / z2;        // Division: erg wird zu 3.4
      System.out.println(erg);
      erg = z1 % z2;        // Modulo: erg wird zu 1.199999
      System.out.println(erg);
      
      // Inkrement und Dekrement
      System.out.println();
      System.out.println(" Inkrement und Dekrement ");
      z1++;                 // z1 wird zu 11.2
      System.out.println(z1);
      --z1;                 // z1 wird zu 10.2
      System.out.println(z1);
      
      // Vergleiche
      System.out.println();
      System.out.println(" Vergleiche ");
      boolean testerg;
      testerg = (z1 == z2);       // Gleich: testerg wird zu false
      System.out.println(testerg);
      testerg = (z1 != z2);       // Ungleich: testerg wird zu true
      System.out.println(testerg);
      testerg = (z1 > z2);        // Gr��er: testerg wird zu true
      System.out.println(testerg);
      testerg = (z1 >= z2);       // Gr��er oder gleich: testerg wird zu true
      System.out.println(testerg);
      testerg = (z1 < z2);        // Kleiner: testerg wird zu false
      System.out.println(testerg);
      testerg = (z1 <= z2);       // Kleiner oder gleich: testerg wird zu false
      System.out.println(testerg);
      
      // Ein- und Ausgabe
      System.out.println();
      System.out.println(" Ein- und Ausgabe ");
      System.out.print(" Geben Sie eine Dezimalzahl ein: ");
      Scanner sc = new Scanner(System.in);
      z1 = sc.nextDouble(); 
      System.out.println(z1);        
      System.console().printf("%f \n", z1);
   }
}
