class Klammern
{
   public static void main(String[] args)                   
   {  
      int x = 2;
      int y;

      y = 3 + x * 4;
      System.out.println(y);          // Ausgabe: 11
      
      y = 3 + (x * 4);
      System.out.println(y);          // Ausgabe: 11
      
      y = (3 + x) * 4;
      System.out.println(y);          // Ausgabe: 20   
   }
}
