import java.util.*;

class Objekte
{
   public static void main(String[] args)                   
   {  
      Date aktuellesDatum = new Date();
      Scanner sc = new Scanner(System.in);
      Date datum = null;
      
      datum = aktuellesDatum;
   }
}
