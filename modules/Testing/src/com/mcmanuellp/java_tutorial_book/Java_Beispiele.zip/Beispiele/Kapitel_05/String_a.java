import java.util.Scanner;

class String_a
{
   public static void main(String[] args)                   
   {  
      String grusswort = "Hallo";
      String name = "";
      String begruessung = "";
      
      System.out.print("Wie heissen Sie? ");
      Scanner sc = new Scanner(System.in);
      name = sc.next();
      
      begruessung = grusswort + " " + name;

      System.out.println("\n" + begruessung);
   }
}
