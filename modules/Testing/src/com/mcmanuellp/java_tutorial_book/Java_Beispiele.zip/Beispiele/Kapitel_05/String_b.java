class String_b
{
   public static void main(String[] args)                   
   {  
      System.out.println();                 
     
      String text = "Hallo, wie geht es Dir?";
      char z = text.charAt(2);
      System.out.println("Zeichen an Position 2: " + z);                 

      int laenge = text.length();         
      System.out.println("Laenge von text: " + laenge);                 

      boolean erg = text.startsWith("H");         
      System.out.println("Beginnt text mit einem H? " + erg);                 

      int pos = text.indexOf('e');         
      System.out.println("Erstes Vorkommen von e an Position: " + pos);                 

      pos = text.lastIndexOf('e');         
      System.out.println("Letztes Vorkommen von e an Position: " + pos);                 
      
      
      System.out.println();                 

      
      String s1, s2;
      s1 = "Hallo, wie geht es Dir?";   
      s2 = s1.replace("Dir","Euch");   
      System.out.println(s1);                 
      System.out.println(s2);                 
      System.out.println();                 

      s1 = "Hallo, wie geht es Dir?";   
      s2 = s1.replace(" Dir","");   
      System.out.println(s1);                 
      System.out.println(s2);                 
      System.out.println();                 

      s1 = "Hallo, wie geht es Dir?";   
      s2 = s1.substring(0, 5);   
      System.out.println(s1);                 
      System.out.println(s2);                 
      System.out.println();                 

      s1 = "Hallo, wie geht es Dir?";   
      s2 = s1.substring(0, s1.indexOf(','));   
      System.out.println(s1);                 
      System.out.println(s2);                 
      System.out.println();                 

      s1 = "Hallo, wie geht es Dir?";   
      s2 = s1.toLowerCase();   
      System.out.println(s1);                 
      System.out.println(s2);                 
      System.out.println();                 

      s1 = " Hallo, wie geht es Dir? ";   
      s2 = s1.trim();   
      System.out.println(s1);                 
      System.out.println(s2);                 
   }
}
