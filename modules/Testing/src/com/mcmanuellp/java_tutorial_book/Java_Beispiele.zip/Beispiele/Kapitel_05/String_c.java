class String_c
{
   public static void main(String[] args)                   
   {  
      StringBuilder gen = 
               new StringBuilder("GUG-CUU-ACG-CCC-GUG-GAG");

      System.out.println("Gen vor der Reparatur : " + gen);  
      
      // Gendefekt reparieren         
      gen.insert(3, "-CAU");         
      gen.setCharAt(21, 'A');         
      gen.append("-AAG");         

      System.out.println("Gen nach der Reparatur: " + gen);  
   }
}
