class Typumwandlung_a
{
   public static void main(String[] args)                   
   {
      int n = 1;
      double r = 2.5;

      n = (int) r;  
      System.out.println("n = " + n);    // Ausgabe: n = 2
   }
}
