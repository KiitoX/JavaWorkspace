class Typumwandlung_b
{
   public static void main(String[] args)                   
   {
      String s = "5";
      int n = 0;

      // Strings in Zahlen umwandeln
      n = Integer.parseInt(s);
      System.out.println("n = " + n);

      n = 125;

      // Zahlen in Strings umwandeln
      s = String.valueOf(n);
      System.out.println("s = " + s);
   }
}
