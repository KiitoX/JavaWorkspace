import java.util.Scanner;

class Ueberlauf
{
   public static void main(String[] args)                   
   {  
      short test;
      // test = Short.MAX_VALUE + 1;   // f�hrt zu Fehlermeldung
      
      Scanner sc = new Scanner(System.in);
      System.out.print(" Ganze Zahl eingeben: ");  
      test = sc.nextShort();                  
      System.out.println(" Wert von test: " + test); 
      
      test += 1000;
      System.out.println(" Nach Addition von 1000: " + test); 
   }
}
