import java.util.Scanner;

class Uebung_Fahrenheit
{
   public static void main(String[] args)
   {
     double fahrenheit;
     double celsius;

     System.out.print(" Geben Sie eine Temperatur in Fahrenheit ein: ");
     Scanner sc = new Scanner(System.in);
     //sc.useLocale(java.util.Locale.ENGLISH);
     fahrenheit = sc.nextDouble();  

     celsius = (fahrenheit - 32.0) * 5.0 / 9.0;

     System.out.println(" " + fahrenheit
         + " Grad Fahrenheit entsprechen "
         + celsius + " Grad Celsius");
         
     //java.io.Console cons = System.console();
     //cons.printf(" %.2f Grad Fahrenheit entsprechen %.2f Grad Celsius \n",
     //            fahrenheit, celsius);    
   }
}
