class Zeichen
{
   public static void main(String[] args)                   
   {  
      char c1 = 'a';
      char c2 = '\u00F8';
      char c3 = '�';
      char c4 = '\\';
      char c5 = (char) (c1 + 1);
      
      System.out.println(c1);
      System.out.println(c2);
      System.out.println(c3);
      System.out.println(c4);
      System.out.println(c5);
   }
}
