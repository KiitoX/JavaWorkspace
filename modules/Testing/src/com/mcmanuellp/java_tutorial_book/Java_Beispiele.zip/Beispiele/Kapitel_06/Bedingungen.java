class Bedingungen
{
   public static void main(String[] args)
   {
      int n = 0, m = 0;
      boolean weiter = false;

      // hier stehen Anweisungen, die n, m und weiter Werte zuweisen

      if (n <= 120)  
      {
         // tue etwas;
      }

      if (weiter)  
      {
         // tue etwas;
      }

      if (n > 100 || n < 0)
      {
         // tue etwas;
      }

      System.out.println(m);
      n = 120;

      if (n > 100 && m++ > 100)
      {
         // tue etwas;
      }

      System.out.println(m);

      if( (n > 100 || n < 0)           // n > 100 oder n < 0
          && (m <= 100 && m >= 0) )    // 0 <= m <= 100
      {
         // tue etwas;
      }
   }
}
