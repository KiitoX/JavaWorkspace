import java.lang.Math.*;

class Continue
{
   public static void main(String[] args)
   {   
      double logarithmus = 0.0;
       
      for(int n = 1; n <= 10; n++)
      {
         logarithmus = Math.log10(n);
         System.out.println(" Logarithmus zur Basis 10 von " + n 
                        + " = " + logarithmus);
      } 
      
      System.out.println();
      
      int n = 1;
      while(n <= 10)
      {
        if (n == 4 || n == 8)
        {
          System.out.println(" Sorry, keine Berechnung fuer " + n);
        }
        else
        {
          logarithmus = Math.log10(n);
          System.out.println(" Logarithmus zur Basis 10 von " + n 
                           + " = " + logarithmus);
        }
        n++;
      } 
      
      System.out.println();
      
      n = 0;
      while(n < 10)
      {
        n++;
        
        if (n == 4 || n == 8)
          continue;
          
        logarithmus = Math.log10(n);
        System.out.println(" Logarithmus zur Basis 10 von " + n 
                         + " = " + logarithmus);
      } 
   }
}
