import java.util.Scanner;

class Dowhile
{
  public static void main(String[] args)
  {   
     double kubikzahl = 0.0;
     int zahl = 0;
      
     do
     {
       System.out.print(" Geben Sie eine Zahl ein (0 zum Beenden): ");
       Scanner sc = new Scanner(System.in);
       zahl = sc.nextInt();  
       kubikzahl = Math.pow(zahl, 3.0);
       System.out.println(" " + zahl + " hoch 3 = " + kubikzahl);
       System.out.println();
       
     } while (zahl != 0); 
  }
}
