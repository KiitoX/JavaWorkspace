import java.util.Scanner;

class Fallthrough
{
   public static void main(String[] args)
   {
      double zahl1, zahl2;
      char op;

      System.out.println("\n Ein kleiner Taschenrechner\n");
      System.out.println("Geben Sie ein: Zahl Operator Zahl <Return>");
      System.out.println("\n");

      Scanner sc = new Scanner(System.in);
      zahl1 = sc.nextInt();  
      op = sc.next().charAt(0);  
      zahl2 = sc.nextInt();  

      switch (op)
      {
         case '+': System.out.println("= " + (zahl1 + zahl2));
                   break;
         case '-': System.out.println("= " + (zahl1 - zahl2));
                   break;
         case 'X':
         case 'x':
         case '*': System.out.println("= " + (zahl1 * zahl2));
                   break;
         case ':':
         case '/': System.out.println("= " + (zahl1 / zahl2));
                   break;
         default:  System.out.println(" Operator nicht bekannt");
         } 
    
      System.out.println();
   }
}
