class For
{
   public static void main(String[] args)
   {   
      double kubikzahl = 0.0;
        
      for (int n = 1; n <= 10; n++)
      {
          kubikzahl = Math.pow(n, 3.0);
          System.out.println(n + " hoch 3 = " + kubikzahl);
      } 
   }
}
