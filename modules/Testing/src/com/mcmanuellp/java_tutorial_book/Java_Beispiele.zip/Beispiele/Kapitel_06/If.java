import java.util.Scanner;

class If
{
   public static void main(String[] args)
   {
      int n;

      System.out.print(" Geben Sie ihr Alter ein: ");
      Scanner sc = new Scanner(System.in);
      n = sc.nextInt();  

      if (n > 120)
      {
         System.out.println(" Soll ich das glauben? ");
      }     

      System.out.println(" Cheerio");
   }
}
