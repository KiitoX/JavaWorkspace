class Strings
{
   public static void main(String[] args)                   
   {  
      String str1 = "Wunder";
      String str2 = "Wanderer";
      
      if ( str1.equals(str2) )
      {
         System.out.println(" str1 ist gleich str2 ");
      }
        
      if ( !str1.equals(str2) )
      {
         System.out.println(" str1 ist ungleich str2 ");
      }
        
      if ( str1.compareTo(str2) > 0 )
      {
         System.out.println(" str1 ist groesser als str2 ");
      }
        
      if ( str1.compareToIgnoreCase(str2) > 0 )
      {
         System.out.println(" str1 ist groesser als str2 ");
      }
   }
}
