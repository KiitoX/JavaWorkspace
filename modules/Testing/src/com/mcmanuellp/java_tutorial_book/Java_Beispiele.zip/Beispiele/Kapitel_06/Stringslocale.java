import java.text.Collator;
import java.util.Locale;
 
class Stringslocale
{
   public static void main(String[] args)                   
   {  
      String str1 = "kurz";
      String str2 = "k�hl";

      /*
      // Zum Vergleich
      System.out.println("\n Vergleich mit String.compareTo: \n");
      if (str1.compareTo(str2) > 0)
      {
         System.out.println(" kurz kommt nach k�hl ");
      }
      else
      {
         System.out.println(" kurz kommt vor k�hl ");
      }
      */
      
      // Erzeuge eine Lokale f�r deutsche Spracheigent�mlichkeiten
      Collator deLokale = Collator.getInstance(new Locale("de", "DE"));

      System.out.println("\n Vergleich mit Collator.compare: \n");
      if (deLokale.compare(str1, str2) > 0)
      {
         System.out.println(" kurz kommt nach k�hl ");
      }
      else
      {
         System.out.println(" kurz kommt vor k�hl ");
      }
      
   }
}
