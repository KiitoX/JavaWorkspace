import java.util.Scanner;

class Switch
{
   public static void main(String[] args)
   {
      int n;
        
      System.out.println(" Hast du vielleicht eine Zahl zwischen"
                       + " 1 und 3 fuer mich?\n");
      Scanner sc = new Scanner(System.in);
      n = sc.nextInt();  
        
      switch(n)
      {
        case 1:   System.out.println(" Knauser, eine kleinere Zahl hast"
                                   + "  du wohl nicht gefunden?");
                  System.out.println();
                  break;
        case 2:   System.out.println(" Etwas mittelmaessig, findest du nicht?");
                  System.out.println();
                  break;
        case 3:   System.out.println(" Wohl groessenwahnsinnig geworden?");
                  System.out.println();
                  break;
        default:  System.out.println("  Zahlen sind nicht gerade deine Staerke.");
                  System.out.println();
      }
   }
}
