import java.util.Scanner;

class Uebung_Menue
{
   public static void main(String[] args)
   {
     char eingabe;

     do
     {
       System.out.println();
       System.out.println(" Festplatte formatieren      <a>");
       System.out.println(" Festplatte waschen          <b>");
       System.out.println(" Festplatte trocknen         <c>");
       System.out.println(" Beenden                     <d>");
       System.out.println();

       System.out.print(" Ihre Eingabe : ");
       Scanner sc = new Scanner(System.in);
       eingabe = sc.next().charAt(0);  
       System.out.println();    

       // Befehl bearbeiten
       switch(eingabe)
       {
         case 'a': System.out.println(" Festplatte wird formatiert ");
                   System.out.println(" krrrrkrrrr ssst");
                   break;
         case 'b': System.out.println(" Festplatte wird gewaschen ");
                   System.out.println(" schrubb schrubb");
                   break;
         case 'c': System.out.println(" Festplatte wird getrocknet ");
                   System.out.println(" sssssssssssssss");
                   break;
         case 'd': System.out.println(" Programm wird beendet ");
                   break;
         default:  System.out.println("Ungueltige Eingabe");
       }
       System.out.println();

     } while (eingabe != 'd');
   }
}
