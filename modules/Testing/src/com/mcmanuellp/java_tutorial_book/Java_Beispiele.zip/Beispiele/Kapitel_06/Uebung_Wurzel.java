import java.util.Scanner;

class Uebung_Wurzel
{
   public static void main(String[] args)
   {
     double eingabe;
     double wurzel;

     System.out.print(" Geben Sie bitte eine positive Zahl ein: ");
     Scanner sc = new Scanner(System.in);
     eingabe = sc.nextDouble();  

     if (eingabe >= 0)
     {
        wurzel = Math.sqrt(eingabe);
        System.out.println(" Wurzel von " + eingabe + " = "
                          + wurzel);
     }
     else
     {
        System.out.println(" Die Wurzel negativer Zahlen kann" + 
                           " nicht berechnet werden.");
     }
   }
}
