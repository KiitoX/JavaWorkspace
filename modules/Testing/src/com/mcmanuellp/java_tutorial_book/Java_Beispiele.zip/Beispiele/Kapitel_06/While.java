class While
{
   public static void main(String[] args)
   {   
      double kubikzahl = 0.0;
       
      int n = 1;
      while (n <= 10)
      {
        kubikzahl = Math.pow(n, 3.0);
        System.out.println(n + " hoch 3 = " + kubikzahl);
        n++;
      }
   }
}
