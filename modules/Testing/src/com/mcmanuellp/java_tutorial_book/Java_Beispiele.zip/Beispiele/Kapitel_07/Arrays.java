class Arrays
{
   public static void main(String[] args)
   {
     int[] lottozahlen = new int[6];

     lottozahlen[2] = 12;
     lottozahlen[3] = 2 * lottozahlen[2];
     
     for (int i : lottozahlen)
        System.out.println(i);
     
   }
}
