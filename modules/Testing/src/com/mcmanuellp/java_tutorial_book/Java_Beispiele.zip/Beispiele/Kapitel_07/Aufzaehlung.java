enum Wochentag {MO, DI, MI, DO, FR, SA, SO};

class Aufzaehlung
{
   public static void main(String[] args)
   {
      int n;
      String[] wochentagname = { "Montag", "Dienstag", 
                                 "Mittwoch", "Donnerstag", 
                                 "Freitag", "Samstag",
                                 "Sonntag" };
      Wochentag tag = Wochentag.MO;
                                 
      // tag = (Wochentag) 3;
      // n = (int) (Wochentag.MO);
      n = Wochentag.MO.ordinal();
      n = tag.ordinal();
      System.out.println(" Integer-Wert von MO   : " + n);
     
     
      System.out.println(" Tag : " + tag);
      System.out.println(" Tag : " + wochentagname[tag.ordinal()]);
   }
}
