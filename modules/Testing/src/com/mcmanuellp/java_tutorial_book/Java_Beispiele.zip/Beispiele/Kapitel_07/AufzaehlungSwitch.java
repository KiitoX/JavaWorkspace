enum Wochentag {MO, DI, MI, DO, FR, SA, SO};

class AufzaehlungSwitch
{
   public static void main(String[] args)
   {
      for (Wochentag tag : Wochentag.values())
      {
         switch (tag)
         {
           case MO:
           case DI:
           case MI:
           case DO:
           case FR:    
                System.out.print(" " + tag + ": ");
                System.out.println(" Puuh, die Woche nimmt kein Ende! ");
                break;
           case SA:
           case SO:    
                System.out.print(" " + tag + ": ");
                System.out.println(" Aaaah, Wochenende! ");
         }
      }
   }
}
