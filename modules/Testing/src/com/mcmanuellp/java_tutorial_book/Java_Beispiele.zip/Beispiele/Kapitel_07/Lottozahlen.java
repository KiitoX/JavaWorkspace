import java.util.Random; 

class Lottozahlen
{
   public static void main(String[] args)
   {
      int[] lottozahlen = new int[6];

      Random generator = new Random();   // Random(1) zum Debuggen

      
      for(int i = 0; i < lottozahlen.length; ++i)
      {
         lottozahlen[i] = generator.nextInt(49) + 1;
      }
      
      for(int i = 0; i < lottozahlen.length; ++i)
      {
         System.out.println( (i+1) + ". Zahl: " + lottozahlen[i]);
      }

      /*
      System.out.println("\n Ausgabe mit for-each-Schleife: \n");
      for(int elem : lottozahlen)
      {
         System.out.println(" Zahl: " + elem);
      }
      */

   }
}
