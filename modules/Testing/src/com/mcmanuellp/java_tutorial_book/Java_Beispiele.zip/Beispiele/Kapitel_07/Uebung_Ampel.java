class Uebung_Ampel
{
   enum Ampel { ROT, ROTGELB, GRUEN, GELB }

   public static void main(String[] args) throws InterruptedException
   {
      String s = "";  
      Ampel ampel = Ampel.ROT;
      int wartezeit = 0;           // in Millisekunden
      long start, ende;
      
      for (int n = 0; n < 12; n++)  
      {
        switch (ampel)
        {
          case ROT:     System.out.println(" Die Ampel ist rot.");
                        ampel = Ampel.ROTGELB;
                        wartezeit = 6000;
                        break;
          case ROTGELB: System.out.println(" Die Ampel ist rotgelb.");
                        ampel = Ampel.GRUEN;
                        wartezeit = 1000;
                        break;
          case GRUEN:   System.out.println(" Die Ampel ist gruen.");
                        ampel = Ampel.GELB;
                        wartezeit = 3000;
                        break;
          case GELB:    System.out.println(" Die Ampel ist gelb.");
                        ampel = Ampel.ROT;
                        wartezeit = 1000;
                        break;
        }
        
        Thread.sleep(wartezeit);
      }
   }
}
