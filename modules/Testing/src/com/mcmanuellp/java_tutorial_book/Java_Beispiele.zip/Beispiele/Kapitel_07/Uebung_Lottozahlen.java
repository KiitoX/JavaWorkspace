import java.util.Random; 

class Uebung_Lottozahlen
{
   public static void main(String[] args)
   {
      int[] lottozahlen = new int[6];
      boolean[] gezogen = new boolean[49];

      Random generator = new Random(); // Random(1) zum Debuggen

      // die Schleife zur Ziehung der Lottozahlen  
      int n = 0;

      do
      {
         lottozahlen[n] = generator.nextInt(49) + 1;

         if (gezogen[lottozahlen[n]-1] == false)
         {
            gezogen[lottozahlen[n]-1] = true;
            n++;
        }
         
      } while (n < lottozahlen.length);


      for(int i = 0; i < lottozahlen.length; ++i)
      {
         System.out.println(i+1 + ". Zahl: " + lottozahlen[i]);
      }
   }
}
