class Absichern
{
   /**
    * Erzeugt eine zuf�llige ganze Zahl aus dem angegebenen Bereich. 
    * Ist min gr��er als max, werden die Werte getauscht.
    *             
    * @param   min  Anfang des Wertebereichs 
    * @param   max  Ende des Wertebereichs 
    * @return       ganze Zahl aus dem Bereich [min,max]
    */ 
   static int zufallszahl(int min, int max)
   {
      if (min > max)
      {
        int tmp = min;
        min = max;
        max = tmp;
      }
      
      return (int) Math.round(Math.random() * (max-min)) + min;
   }


   public static void main(String[] args)
   {
      System.out.println(" Test der Zufallszahlen-Funktion");
     
      int n = 0;
      for (int i = 0; i < 100; i++)
      {
        n = zufallszahl(0,50);
        System.out.print(" " + n);
      }
      System.out.println("\n");

      for (int i = 0; i < 100; i++)
      {
        n = zufallszahl(1,12);
        System.out.print(" " + n);
      }
      System.out.println("\n");
      
      for (int i = 0; i < 100; i++)
      {
        n = zufallszahl(-50,50);
        System.out.print(" " + n);
      }
      System.out.println("\n");
      
      for (int i = 0; i < 100; i++)
      {
        n = zufallszahl(50,0);
        System.out.print(" " + n);
      }
      System.out.println("\n");
   }
}
