class Befehlszeile
{
   public static void main(String[] args)
   {
      System.out.println();
      System.out.println(" Befehlszeilenargumente:\n");
      
      String s;
      for(int i = 0; i < args.length; i++)
      {
        System.out.println(i+1 + ". Argument: " + args[i]);
      }
   }
}
