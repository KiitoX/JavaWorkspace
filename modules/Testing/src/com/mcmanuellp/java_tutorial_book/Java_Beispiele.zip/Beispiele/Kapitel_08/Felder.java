class Felder
{
   private static int codezahl = 0;
   
   
   private static void aktualisieren()
   {
      codezahl = (3 * codezahl) - 7;
   }


  
   
   
   public static void main(String[] args)
   {
      codezahl = 1;
      
      System.out.println(" Codezahl = " + codezahl);

      aktualisieren();

      System.out.println(" Codezahl = " + codezahl);
   }
}
