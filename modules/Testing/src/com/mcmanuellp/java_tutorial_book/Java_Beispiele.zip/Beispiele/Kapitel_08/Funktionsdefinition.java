
// Allgemeines Schema:
//
// class IrgendeineKlasse
// {
//    <Zugriff> <Modifizierer> <R�ckgabetyp> Name( <Parameter> )
//    {
//       <Anweisungen>
//    }
// }

class Funktionsdefinition
{
   static int demo()
   {
      System.out.println(" Hallo aus demo()");
      
      return 1;
   }

   public static void main(String[] args)
   {
      System.out.println(" Das Programm wurde gestartet.");

      // ... 

      demo();

      // ... 

      int n = demo();
      System.out.println(" n = " + n);
   }
}
