import java.util.Random; 

class Parameter
{
   static int zufallszahl(int min, int max)
   {
      return (int) Math.round(Math.random() * (max-min)) + min;
   }


   public static void main(String[] args)
   {
      System.out.println(" Test der Zufallszahlen-Funktion");

      int n = 0;
      for (int i = 0; i < 100; i++)
      {
        n = zufallszahl(0,50);
        System.out.print(" " + n);
      }
      System.out.println();

      n = zufallszahl(1,12);
      System.out.println(" " + n);
      n = zufallszahl(-50,50);
      System.out.println(" " + n);
      n = zufallszahl(50,0);
      System.out.println(" " + n);
   }
}
