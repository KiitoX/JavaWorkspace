class Referenzparameter
{
   static void verdoppeln(int n)
   {
      n *= 2;
   }
   static void verdoppeln(StringBuilder s)
   {
      s.append(s);
   }
      
      
   public static void main(String[] args)
   {
      System.out.println(" \n Uebergabe von int \n");
      int n = 5;
      System.out.println(" n = " + n);   // 5
      verdoppeln(n);
      System.out.println(" n = " + n);   // 5
      
      System.out.println(" \n Uebergabe von StringBuilder \n");
      StringBuilder sb = new StringBuilder("Hallo ");
      
      System.out.println(" s = " + sb);  // "Hallo"
      verdoppeln(sb);
      System.out.println(" s = " + sb);  // "Hallo Hallo "
   }
}
