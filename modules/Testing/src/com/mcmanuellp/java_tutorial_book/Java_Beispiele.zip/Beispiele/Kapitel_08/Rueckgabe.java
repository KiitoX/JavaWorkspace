class Rueckgabe
{
   static int zahl_1_10()
   {
      int zahl = (int) Math.round(Math.random() * 9) + 1;
      
      return zahl;
   }


   public static void main(String[] args)
   {
      System.out.println(" Test der Zufallszahlen-Funktion");
     
      int n = 0;
      for (int i = 0; i < 50; i++)
      {
        n = zahl_1_10();
        System.out.println(" gezogene Zahl: " + n);
      }
   }
}
