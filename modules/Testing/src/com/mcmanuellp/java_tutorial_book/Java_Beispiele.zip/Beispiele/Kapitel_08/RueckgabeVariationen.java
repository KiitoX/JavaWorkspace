class RueckgabeVariationen
{
   static int zahl_1_10()
   {
      return (int) Math.round(Math.random() * 9) + 1;
   }

   static void gruss()
   {
      System.out.println("Hallo");
   }

   public static void main(String[] args)
   {
      int n = 0;
      for (int i = 0; i < 20; i++)
      {
         n = i * zahl_1_10();
         
         if (n > 20 && zahl_1_10() >= 5)
            System.out.println(" Bingo ");
            
         System.out.println(" Ziehung: " + zahl_1_10());
      }
   }
}
