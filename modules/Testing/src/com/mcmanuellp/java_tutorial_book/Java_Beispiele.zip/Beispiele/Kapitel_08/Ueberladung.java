class Ueberladung
{
   static String trennlinie(int anzahl, char c)      // Version 1
   {
      StringBuilder s = new StringBuilder("");
      for (int i = 0; i < anzahl; i++)
         s.append(c);
         
      return s.toString();
   }
   static String trennlinie(int anzahl, String str)  // Version 2
   {
      StringBuilder s = new StringBuilder("");
      for (int i = 0; i < anzahl; i++)
         s.append(str);
         
      return s.toString();
   }
     

   public static void main(String[] args)
   {
      System.out.println(trennlinie(10, '*'));  //ruft Version 1 auf
      System.out.println(trennlinie(5, "*-"));  //ruft Version 2 auf
   }
}
