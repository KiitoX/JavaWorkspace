import java.util.Scanner;

class Uebung_Woerter
{
   /**
    * Z�hlt, wie viele W�rter in dem �bergebenen Text 
    * vorhanden sind. Als Wortgrenzen werden Leerzeichen, 
    * Tabulator und Zeilenumbruch ber�cksichtigt.
    *             
    * @param   text  Text, dessen W�rter gez�hlt werden sollen 
    * @return        Anzahl der W�rter im Text
    */ 
   static int woerterZaehlen(String text)
   {
            /* Version A:
            String[] woerter = text.split("[ \t\n]");
            
            return woerter.length;
            */
            
            /* Version B 
            int anzahl = 0;
            
            String[] woerter = text.split("[ \t\n]");
            
            for (String s : woerter)
            {
               s = s.trim();
               if (s.length() != 0)
                  anzahl++;
            }
            
            return anzahl;
            */
      
      // endg�ltige Version
      int anzahl = 0;
      String[] woerter = text.split("[ \t\n]+");
      anzahl = woerter.length;
      
      // Korrektur f�r Text, der mit Whitespace beginnt
      if (woerter[0].length() == 0)
         anzahl -= 1;
      
      return anzahl;
   }
   

   public static void main(String[] args)                             
   {  
      Scanner sc = new Scanner(System.in);
      StringBuilder sb = new StringBuilder();
      
      while (sc.hasNextLine())
      {  
         sb.append(sc.nextLine());
         sb.append("\n");
      }
      
      System.out.println(" Anzahl Woerter in Text: "
                         + woerterZaehlen(sb.toString()) );   
   }  
}
