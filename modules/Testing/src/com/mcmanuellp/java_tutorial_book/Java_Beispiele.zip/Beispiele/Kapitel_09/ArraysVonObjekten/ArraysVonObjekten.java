class Demo
{
   int wert;
   
   Demo()       { wert = 11; }
   Demo(int n)  { wert = n; }
}

class ArraysVonObjekten
{
   public static void main(String[] args)
   {
      Demo[] objekte = new Demo[6];
      
      for(int i = 0; i < objekte.length; ++i)
      {
         objekte[i] = new Demo(i);
      }      
      
      for(Demo obj : objekte)
      {
         if (obj == null)
             System.out.print(" null");
         else
            System.out.print(" " + obj.wert);
      }
   }
}
