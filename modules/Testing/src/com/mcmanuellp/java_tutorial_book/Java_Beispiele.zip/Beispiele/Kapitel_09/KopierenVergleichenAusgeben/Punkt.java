public class Punkt
{
   int x = 0;
   int y = 0;

   public Punkt()              {  }

   public Punkt(int n, int m)  { x = n;
                                 y = m; }   

   public void verschieben(int dx, int dy) 
   {
      x += dx;
      y += dy; 
   }
}



class Testprogramm
{
   public static void main(String[] args)                             
   {   
      Punkt punktA = new Punkt(1, 10);          
      Punkt punktB = new Punkt(1, 10);          

      if (punktB != punktA)
      {
         System.out.println(" ungleich ");
      }
 
      punktB = punktA;
      
      System.out.println(punktA);
      System.out.println(punktB);
   } 
}
