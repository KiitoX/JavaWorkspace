class Punkt
{
   int x = 0;
   int y = 0;

   Punkt()              {  }

   Punkt(int n, int m)  { x = n;
                          y = m; }   
   
   void verschieben(int dx, int dy) 
   {
      x += dx;
      y += dy; 
   }
}


class PunktDemo
{
   public static void main(String[] args)                             
   {   
      Punkt pA = new Punkt(1,0);
      Punkt pB = new Punkt(5,5);

      pA.verschieben(10, 5);   // pA.x wird zu 11, pA.y wird zu 5
      pB.verschieben(10, 5);   // pA.x wird zu 15, pA.y wird zu 10
      
      System.out.println();
      System.out.println(" Punkt pA: (" + pA.x + "," + pA.y + ")");
      System.out.println(" Punkt pB: (" + pB.x + "," + pB.y + ")");
   } 
}
