import java.util.Scanner;

public class Uebung_BuchstabenZaehlen
{
   public static void main(String[] args)
   {
      Zaehler zaehler = new Zaehler();
      String eingabe = "";
      
      System.out.print(" Bitte einen Text eingeben:   ");
      Scanner sc = new Scanner(System.in);
      eingabe = sc.nextLine();

      int pos = -1;
      while ( (pos = eingabe.indexOf('a', pos+1)) != -1)
      {
        zaehler.erhoehen();
      }
      
      System.out.println(" In dem String gibt es " 
                         + zaehler.getStand() 
                         + " Vorkommen des Zeichens a"); 
   }
}
