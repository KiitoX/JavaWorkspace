public class Zaehler 
{
   private int stand;    

   public Zaehler()                  { stand = 0; }
   public Zaehler(int startwert)     { stand = startwert; }
    
   public void erhoehen()            { ++stand; }    
   public void zuruecksetzen()       { stand = 0; }    
   public int getStand()             { return stand; }
}
