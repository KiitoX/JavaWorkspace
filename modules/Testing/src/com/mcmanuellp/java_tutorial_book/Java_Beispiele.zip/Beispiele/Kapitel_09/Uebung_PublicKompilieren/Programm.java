class VerwendetZaehler
{
   public static void main(String[] args)
   {
      Zaehler zaehler1 = new Zaehler();
      Zaehler zaehler2 = new Zaehler(9);
      
      System.out.println(" Stand des Zaehlers 1:   " + zaehler1.getStand());
      System.out.println(" Stand des Zaehlers 2:   " + zaehler2.getStand());
      
      zaehler1.erhoehen();
      
      System.out.println(" Stand des Zaehlers 1:   " + zaehler1.getStand());
      System.out.println(" Stand des Zaehlers 2:   " + zaehler2.getStand());
   }
}
