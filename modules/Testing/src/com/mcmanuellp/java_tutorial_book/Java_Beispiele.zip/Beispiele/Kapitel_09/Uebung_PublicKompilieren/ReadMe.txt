Um dieses Programm zu kompilieren, kannst du einen der folgenden Befehle

javac Programm.java
javac Programm.java Zaehler.java
javac *.java

verwenden



Zum Ausf�hren des Programms verwendest du den Befehl

java VerwendetZaehler