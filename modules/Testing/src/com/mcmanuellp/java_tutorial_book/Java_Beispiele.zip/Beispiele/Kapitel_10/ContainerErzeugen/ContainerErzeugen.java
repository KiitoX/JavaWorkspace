import java.util.*;

class ContainerErzeugen
{
   public static void main(String[] args)
   {
      ArrayList<Integer> zahlen = new ArrayList<Integer>(5);

      for(int i = 0; i < 5; i++)
      {
         zahlen.add(i);
      }

      for(int i = 0; i < zahlen.size(); i++)
      {
        System.out.println(i + ": " + zahlen.get(i));
      }
      
      System.out.println("\n");
   }
}
