import java.util.*;

class ElementeDurchlaufen
{
   public static void main(String[] args)
   {
      ArrayList<Integer> zahlen = new ArrayList<Integer>(5);

      for(int i = 0; i < 5; i++)
      {
         zahlen.add(i);
      }
      
      System.out.println("\n Durchlaufen mit get(): ");
      for(int i = 0; i < zahlen.size(); i++)
      {
        System.out.print(" " + zahlen.get(i));
      }
      
      System.out.println("\n Durchlaufen mit Iterator: ");
      Iterator<Integer> iter = zahlen.iterator();
      while(iter.hasNext())
      {
        System.out.print(" " + iter.next());
      }
      
      System.out.println("\n Durchlaufen mit ListIterator: ");
      ListIterator<Integer> listIter = zahlen.listIterator(0);
      while(listIter.hasNext())
      {
        System.out.print(" " + listIter.next());
      }
      
      System.out.println("\n Durchlaufen mit for-each: ");
      for (int n : zahlen) 
      {
         System.out.print(" " + n);
      }
      
      System.out.println("\n");
   }
}
