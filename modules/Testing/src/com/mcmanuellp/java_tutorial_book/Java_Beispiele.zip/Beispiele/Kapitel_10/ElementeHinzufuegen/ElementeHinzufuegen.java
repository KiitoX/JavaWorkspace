import java.util.*;

class ElementeHinzufuegen
{
   public static void main(String[] args)
   {
      LinkedList<Integer> container = new LinkedList<Integer>();
      int wert;
      
      for(wert = 0; wert < 5; wert++)
      {
         container.add(wert);
      }

      wert = 100;
      container.add(3, wert);

      
      // Kontrollausgabe
      for(int n : container)
      {
         System.out.print(" " + n);
      }
      System.out.println();

      
      container.remove(new Integer(3));
      container.remove(0);

      
      // Kontrollausgabe
      for(int n : container)
      {
         System.out.print(" " + n);
      }
      System.out.println();

   }
}
