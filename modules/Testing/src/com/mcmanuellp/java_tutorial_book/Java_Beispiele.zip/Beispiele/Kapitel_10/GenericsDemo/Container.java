public class Container<T>
{
   private T wert;
   
   public T getWert()         { return wert; }
   public void setWert(T n)   { wert = n; }
   public int anzahl()        { return 1; }
}

