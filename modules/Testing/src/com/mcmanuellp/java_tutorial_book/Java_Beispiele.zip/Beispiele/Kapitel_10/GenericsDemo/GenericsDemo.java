class GenericsDemo
{
   public static void main(String[] args)                             
   { 
      Container<Integer> c = new Container<Integer>();          
      Container<Double> d = new Container<Double>();          
      Container<Punkt> e = new Container<Punkt>();          
      
      System.out.println(c.getWert());
      c.setWert(12);
      System.out.println(c.getWert());
      
      System.out.println(d.getWert());
      d.setWert(-43.1);
      System.out.println(d.getWert());
      
      System.out.println(e.getWert());
      e.setWert(new Punkt(1,2));
      System.out.println(e.getWert());
   } 
}
