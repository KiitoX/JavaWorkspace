class Punkt
{
   int x = 0;
   int y = 0;

   Punkt()              {  }

   Punkt(int n, int m)  { x = n;
                          y = m; }   
   
   void verschieben(int dx, int dy) 
   {
      x += dx;
      y += dy; 
   }
}

