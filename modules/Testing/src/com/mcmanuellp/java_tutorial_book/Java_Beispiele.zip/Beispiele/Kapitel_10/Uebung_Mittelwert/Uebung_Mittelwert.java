import java.util.*;

class Uebung_Mittelwert
{
   public static void main(String[] args)
   {
      ArrayDeque<Integer> messwerte = new ArrayDeque<Integer>();
      Scanner sc = new Scanner(System.in);
      int n;

      System.out.println();
      System.out.println(" ** Zum Beenden der Eingabe e eintippen **");
      System.out.println();

      // Werte einlesen
      while (true) 
      {
         System.out.print(" Geben Sie einen Messwert ein: ");

         if (sc.hasNextInt() == false)
            break;
            
         n = sc.nextInt(); 
         messwerte.add(n);
      }

      // Mittelwert berechnen und ausgeben
      double mittelwert = 0;
      double summe      = 0;

      Iterator<Integer> iter = messwerte.iterator();
      while(iter.hasNext())
         summe += iter.next();
         
      mittelwert = summe/messwerte.size();

      System.out.println();
      System.out.println(" Der Mittelwert betraegt: " 
                         + mittelwert + "\n");
   }
}
