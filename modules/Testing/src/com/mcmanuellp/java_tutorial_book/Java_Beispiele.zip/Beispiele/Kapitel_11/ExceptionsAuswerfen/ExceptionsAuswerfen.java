class ExceptionsAuswerfen
{
static double division(int zaehler, int nenner) 
{
    if(nenner == 0) 
    {
        IllegalArgumentException e = new IllegalArgumentException(
                         "Fehler: versuchte Division durch Null");
        throw e;
    }
    
    return zaehler / nenner;
}

   public static void main(String[] args) 
   {
       try 
       {
           double bruch;
           
           bruch = division(12,5);
           System.out.println(bruch);
           
           bruch = division(12,-5);
           System.out.println(bruch);
           
           bruch = division(12,0);  // l�st Exception aus
           System.out.println(bruch);
       }
       catch(IllegalArgumentException e) 
       {
           System.err.println();
           System.err.println(e.getMessage());
       }
   }
}
