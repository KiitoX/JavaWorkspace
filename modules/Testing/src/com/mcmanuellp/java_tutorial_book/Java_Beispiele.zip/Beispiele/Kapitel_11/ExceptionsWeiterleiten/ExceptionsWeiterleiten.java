import java.io.*;

class ExceptionsWeiterleiten
{
   static void demo()  throws FileNotFoundException
   {
      PrintWriter datei = new PrintWriter("unbekannt.txt");
      // ...
   }
   
   public static void main(String[] args)  
   {
      try
      {
         demo();
      }
      catch (FileNotFoundException e) 
      {
      }
   }
}
