class Uebung_Zufallszahl
{
   /**
    * Erzeugt eine zuf�llige ganze Zahl aus dem angegebenen Bereich. 
    * Ist min gr��er als max, werden die Werte getauscht.
    *             
    * @param   min  Anfang des Wertebereichs 
    * @param   max  Ende des Wertebereichs 
    * @return       ganze Zahl aus dem Bereich [min,max]
    */ 
   static int zufallszahl(int min, int max)
   {
      if (min > max)
      {
         throw new IllegalArgumentException(
                  "Fehler in zufallszahl: min ist groesser als max");
      }
      
      return (int) Math.round(Math.random() * (max-min)) + min;
   }


public static void main(String[] args)
{
   System.out.println("\n" + " Test der Zufallszahlen-Funktion\n");
  
   int n = 0;
   for (int i = 5; i > -5; i--)
   {
      try
      {
         n = zufallszahl(4,i*i);
         System.out.println(" " + n);
      }
      catch(IllegalArgumentException e)
      {
         System.err.println("\n " + e.getMessage()); 
      }
   }
}
}
