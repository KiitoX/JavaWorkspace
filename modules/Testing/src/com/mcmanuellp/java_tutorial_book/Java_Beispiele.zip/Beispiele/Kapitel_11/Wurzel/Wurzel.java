import java.lang.Math.*;

class Wurzel
{
static double wurzelA(double r)
{
   if (r < 0)
   {
      r = 2;
   }
   
   return Math.sqrt(r);
}

static double wurzelB(double r)
{
   if (r < 0)
   {
      return -1;
   }
   
   return Math.sqrt(r);
}

static double wurzelC(double r)
{
   if (r < 0)
   {
      System.err.println(" Fehler: Negatives Argument");
      return -1;
   }
   
   return Math.sqrt(r);
}


   public static void main(String[] args)
   {
     double eingabe;
     double wurzel;
     
     System.out.println(wurzelA(64));
     System.out.println(wurzelA(0));
     System.out.println(wurzelA(-10));

     System.out.println(wurzelB(64));
     System.out.println(wurzelB(0));
     System.out.println(wurzelB(-10));

     System.out.println(wurzelC(64));
     System.out.println(wurzelC(0));
     System.out.println(wurzelC(-10));
   }
}
