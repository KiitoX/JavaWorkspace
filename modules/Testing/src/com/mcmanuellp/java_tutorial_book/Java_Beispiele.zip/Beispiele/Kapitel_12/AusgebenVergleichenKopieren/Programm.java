class Programm
{
   public static void main(String[] args)
   {
      Vektor vekt1 = new Vektor(1,2);       
      Vektor vekt2 = new Vektor(1,-2);       
      Vektor vekt3 = new Vektor(1,2);  

      // String-Umwandlung und Ausgabe
      System.out.println("\n *** Teste toString() *** \n");
      System.out.println(" vekt1 = " + vekt1);
      System.out.println(" vekt2 = " + vekt2);
      System.out.println(" vekt3 = " + vekt3);
                                        
      // Kopieren
      System.out.println("\n *** Teste Kopierkonstruktor *** \n");
      System.out.println(" Erzeugt vekt4 als Kopie von vekt2 \n");
      Vektor vekt4 = new Vektor(vekt2);
      System.out.println(" vekt4 = " + vekt4);

      // Gleichheit
      System.out.println("\n *** Teste equals() *** \n");
      if (vekt2 == vekt4)
         System.out.println(" Verweise in vekt2 und vekt4 gleich ");
      else
          System.out.println(" Verweise in vekt2 und vekt4 ungleich ");
      if (vekt2.equals(vekt4))
         System.out.println(" Objekte vekt2 und vekt4 gleich ");
      else
          System.out.println(" Objekte vekt2 und vekt4 ungleich ");
     
      System.out.println("\n veraendere vekt4 \n");
      vekt4.setX(50);  
      System.out.println(" vekt4 = " + vekt4);

      System.out.println();
      if (vekt2 == vekt4)
         System.out.println(" Verweise in vekt2 und vekt4 gleich ");
      else
          System.out.println(" Verweise in vekt2 und vekt4 ungleich ");
      if (vekt2.equals(vekt4))
         System.out.println(" Objekte vekt2 und vekt4 gleich ");
      else
          System.out.println(" Objekte vekt2 und vekt4 ungleich ");

      System.out.println();
      if (vekt1 == vekt2)
         System.out.println(" Verweise in vekt1 und vekt2 gleich ");
      else
          System.out.println(" Verweise in vekt1 und vekt2 ungleich ");
      if (vekt1.equals(vekt2))
         System.out.println(" Objekte vekt1 und vekt2 gleich ");
      else
          System.out.println(" Objekte vekt1 und vekt2 ungleich ");
          
      System.out.println();
      if (vekt1 == vekt3)
         System.out.println(" Verweise in vekt1 und vekt3 gleich ");
      else
          System.out.println(" Verweise in vekt1 und vekt3 ungleich ");
      if (vekt1.equals(vekt3))
         System.out.println(" Objekte vekt1 und vekt3 gleich ");
      else
          System.out.println(" Objekte vekt1 und vekt3 ungleich ");
         
   }
}
