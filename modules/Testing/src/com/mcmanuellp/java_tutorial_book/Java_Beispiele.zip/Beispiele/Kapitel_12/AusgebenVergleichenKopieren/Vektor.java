public class Vektor
{
   private double x = 0;
   private double y = 0;
   
   public Vektor()               { }   
   
   public Vektor(Vektor v)
   {
      this.x = v.x;
      this.y = v.y;
   }
   
   public Vektor(double x, double y)
   {
      this.x = x;
      this.y = y;
   }
   
   public double getX()          { return x; }
   public double getY()          { return y; }
   public void setX(double x)    { this.x = x; }
   public void setY(double y)    { this.y = y; }
   
   public double laenge() 
   {
     return Math.sqrt(x*x + y*y);
   }  
   public void addieren(Vektor v)
   {
     x += v.x;
     y += v.y;
   }  
   public void subtrahieren(Vektor v)
   {
     x -= v.x;
     y -= v.y;
   }

   public String toString()
   {
      java.text.NumberFormat nf = java.text.NumberFormat.getInstance();
      nf.setMaximumFractionDigits(2);
      
      return "(" + nf.format(x) 
             + " , " + nf.format(y) + ")";
   }
   
   public boolean equals(Object obj) 
   {
      if (obj == this)                      // Schnelltest f�r Reflexivit�t
         return true;  

      if (obj == null)                      // Schnelltest auf null
         return false;

      if (obj.getClass() != getClass() )    // wegen Symmetrie
         return false;

      Vektor v = (Vektor) obj;

      return ( (v.x == x) && (v.y == y) );  // eigentlicher Vergleich
   }

   public int hashCode() 
   {
      long bits = Double.doubleToLongBits(getX());
      bits ^= Double.doubleToLongBits(getY()) * 31;
      return (((int) bits) ^ ((int) (bits >> 32)));
   }
   
}
