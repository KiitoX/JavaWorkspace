public class Bildschirmpunkt
{
   public static final int maxBildschirmX = 1280; 
   public static final int maxBildschirmY = 1024; 
   
   private int x;
   private int y;
  
   public Bildschirmpunkt()                 { }    
   public Bildschirmpunkt(int x, int y)     { this.x = checkX(x); 
                                              this.y = checkY(y); }   
   
   public void verschieben(int dx, int dy)  { x = checkX(x + dx); 
                                              y = checkY(y + dy); }
                                              
   public int  getX()                   { return x; }
   public void setX(int x)              { this.x = checkX(x); }
   public int  getY()                   { return y; }
   public void setY(int y)              { this.y = checkY(y); }
   
   private int checkX(int x)  
   { 
      if ( x < 0)              
         return 0;
      if ( x > maxBildschirmX) 
         return maxBildschirmX;
         
      return x;  
   }
   private int checkY(int y)
   { 
      if ( y < 0)              
         return 0;
      if ( y > maxBildschirmY) 
         return maxBildschirmY;
         
      return y;  
   }
}
