public class Getset
{
   public static void main(String[] args)                             
   {  
      {
      Punkt punktA = new Punkt(10,0);  
      System.out.println(" nach punktA = new Punkt(10,0);");
      System.out.println(" punktA: (" + punktA.x + "," + punktA.y + ")");

      Punkt punktB = new Punkt();          
      punktB = punktA;   
      System.out.println(" nach punktB = punktA");
      System.out.println(" punktB: (" + punktB.x + "," + punktB.y + ")");
      
      punktB.verschieben(10, -10);
      System.out.println(" nach punktB.verschieben(10, -10);");
      System.out.println(" punktA: (" + punktA.x + "," + punktA.y + ")");
      System.out.println(" punktB: (" + punktB.x + "," + punktB.y + ")");
      }

      {
      System.out.println("\n\nBildschirmpunkt\n");
      
      Bildschirmpunkt punktA = new Bildschirmpunkt(10,0);          
      System.out.println(" nach punktA = new Bildschirmpunkt(10,0);");
      System.out.println(" punktA: (" + punktA.getX() + "," + punktA.getY() + ")");
      
      Bildschirmpunkt punktB = new Bildschirmpunkt();          
      System.out.println(" nach punktB = new Bildschirmpunkt();");
      System.out.println(" punktB: (" + punktB.getX() + "," + punktB.getY() + ")");
      
      punktB.setX(250);
      System.out.println(" nach punktB.setX(250);");
      System.out.println(" punktB: (" + punktB.getX() + "," + punktB.getY() + ")");
      
      punktB = punktA;   
      System.out.println(" nach punktB = punktA");
      System.out.println(" punktB: (" + punktB.getX() + "," + punktB.getY() + ")");
      
      punktB.verschieben(10, -50);
      System.out.println(" nach punktB.verschieben(10, -50);");
      System.out.println(" punktA: (" + punktA.getX() + "," + punktA.getY() + ")");
      System.out.println(" punktB: (" + punktB.getX() + "," + punktB.getY() + ")");
      
      Bildschirmpunkt punktC = new Bildschirmpunkt(-1,0);          
      System.out.println(" nach punktC = new Bildschirmpunkt(-1,0);");
      System.out.println(" punktC: (" + punktC.getX() + "," + punktC.getY() + ")");
      Bildschirmpunkt punktD = new Bildschirmpunkt(-1,2000);          
      System.out.println(" nach punktD = new Bildschirmpunkt(-1,2000);");
      System.out.println(" punktD: (" + punktD.getX() + "," + punktD.getY() + ")");
     
      punktC.setX(-120);
      System.out.println(" nach punktC.setX(-120);");
      System.out.println(" punktC: (" + punktC.getX() + "," + punktC.getY() + ")");
      punktD.setY(3334);
      System.out.println(" nach punktD.setX(3334);");
      System.out.println(" punktD: (" + punktD.getX() + "," + punktD.getY() + ")");

      punktC.verschieben(2000, -2000);
      System.out.println(" nach punktC.verschieben(2000, -20900);");
      System.out.println(" punktC: (" + punktC.getX() + "," + punktC.getY() + ")");
      
      }
   } 
}
