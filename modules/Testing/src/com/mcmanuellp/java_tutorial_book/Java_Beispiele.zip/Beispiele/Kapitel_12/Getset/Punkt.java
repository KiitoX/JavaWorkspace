public class Punkt
{
   public int x;
   public int y;

   public Punkt()              {  }

   public Punkt(int n, int m)  { x = n;
                                 y = m; }   

   public void verschieben(int dx, int dy) 
   {
      x += dx;
      y += dy; 
   }
}