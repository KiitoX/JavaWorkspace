class Demo
{
   public Punkt ursprung = new Punkt(0,0);
   public Punkt p;

   public Demo()               { }
   public Demo(int x, int y)   { p = new Punkt(x,y); }
   // ...   
}

class Konstruktoren
{
   public static void main(String[] args)                             
   {   
      Demo obj1 = new Demo();   
      Demo obj2 = new Demo(-1,2);      
      
      System.out.println(" Demo-Objekt obj1: ");
      
      if (obj1.p == null)
         System.out.println("\t obj1.p = null");
      else
      {
         System.out.println(" \t obj1.p.x = " + obj1.p.x);
         System.out.println(" \t obj1.p.y = " + obj1.p.y);
      }
      
      
      System.out.println(" Demo-Objekt obj2: ");
      
      if (obj2.p == null)
         System.out.println("\t obj2.p = null");
      else
      {
         System.out.println(" \t obj2.p.x = " + obj2.p.x);
         System.out.println(" \t obj2.p.y = " + obj2.p.y);
      }
   } 
}
