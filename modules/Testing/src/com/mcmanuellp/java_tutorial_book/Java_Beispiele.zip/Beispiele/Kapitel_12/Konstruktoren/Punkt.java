public class Punkt
{
   public int x = 0;
   public int y = 0;

   public Punkt()              {  }
   public Punkt(int n, int m)  { x = n;
                                 y = m; }   
}

