public class Singleton 
{
   private static Singleton instanz = null; 
    
   private Singleton() {}    // direkte Instanzbildung unterbinden
    
   public static Singleton getInstanz()  
   {
      if (instanz == null)  
         instanz = new Singleton();
          
      return instanz;
   }
}
