class SingletonDemo
{
   public static void main(String[] args) 
   {
      Singleton obj1 = Singleton.getInstanz();
      Singleton obj2 = Singleton.getInstanz();
       
      if (obj1 == obj2)
         System.out.println(" identische Verweise ");
      else
         System.out.println(" unterschiedliche Verweise ");
   }
}
