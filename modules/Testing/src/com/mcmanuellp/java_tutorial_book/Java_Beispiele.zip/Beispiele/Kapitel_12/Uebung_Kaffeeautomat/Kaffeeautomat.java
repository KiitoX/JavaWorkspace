import java.util.Scanner;

class Bestellung
{
   boolean   zucker;
   boolean   milch;
   double preis;
   double eingang;
   
   Bestellung()
   {
      zucker = false;
      milch = false; 
      preis = 0.0; 
      eingang = 0.0;      
   }
                  
   void loeschen() 
   {
      zucker = false;
      milch = false; 
      preis = 0.0; 
      eingang = 0.0;      
   }
}


public class Kaffeeautomat
{
   private double geldbestand;
   private Bestellung order = new Bestellung();

   public Kaffeeautomat() 
   {
      geldbestand = 10.0;
   }
   
   public void bestellungAufnehmen()
   {
      String eingabe;
      
      order.loeschen();      // Alte Bestelldaten l�schen
      order.preis += 1.00;   // Preis f�r Kaffee
      
      System.out.print(" Moechten Sie Zucker dazu?        (j/n) : ");
      Scanner sc = new Scanner(System.in);
      eingabe = sc.next(); 
      if (eingabe.equals("j") == true)
      {
         order.preis += 0.10;   // Preis f�r Zucker
         order.zucker = true;
      }

      System.out.print(" Moechten Sie Milch dazu?         (j/n) : ");
      eingabe = sc.next(); 
      if (eingabe.equals("j") == true)
      {
         order.preis += 0.20;   // Preis f�r Milch
         order.milch = true;
      }
      System.out.println();   
   }
   
   public void kassieren()
   {
      double einzahlung;
      
      System.out.println(" Das kostet zusammen " + order.preis + " Euro");
      System.out.print(" Eingezahlter Betrag: ");
      Scanner sc = new Scanner(System.in);
      einzahlung = sc.nextDouble(); 
      order.eingang = einzahlung;
      while (order.eingang < order.preis) 
      {
         System.out.println(" Noch zu zahlen: " + (order.preis - order.eingang));
         System.out.print(" Zugezahlter Betrag: ");
         einzahlung = sc.nextDouble(); 
         order.eingang += einzahlung;
      }
      
      double rueckgeld = order.eingang - order.preis;
      
      einzahlungVerbuchen(order.eingang);
      rueckgeldAuszahlen(rueckgeld);
      
      System.out.println(" Ihr Rueckgeld: " + rueckgeld + "\n");
      System.out.println(" Neuer Bestand: " + geldbestand + "\n");
   }

   public void ausschenken()
   {
      kaffeeAusschenken();

      if (order.zucker)
         zuckerHinzufuegen();

      if (order.milch)
         milchHinzufuegen();
   }
      
   
   private void einzahlungVerbuchen(double eingang)  { geldbestand += eingang; }
   private void rueckgeldAuszahlen(double rueckgeld) { geldbestand -= rueckgeld; }
   private void kaffeeAusschenken() { System.out.println("\t Hier kommt der Kaffee!"); }
   private void zuckerHinzufuegen() { System.out.println("\t Ein bisschen Zucker!"); }
   private void milchHinzufuegen()  { System.out.println("\t Ein bisschen Milch!"); }
}
