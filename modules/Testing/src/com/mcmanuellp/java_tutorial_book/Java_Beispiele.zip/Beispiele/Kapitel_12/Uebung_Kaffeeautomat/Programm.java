import java.util.Scanner;

class Programm
{
   public static void main(String[] args)
   {
      Kaffeeautomat automat = new Kaffeeautomat();

      while (true) 
      {
         String eingabe;
         System.out.print("\n" + " Moechten Sie einen Kaffee?       (j/n) : ");
         Scanner sc = new Scanner(System.in);
         eingabe = sc.next();

         if (eingabe.equals("j") == false)
            break;
            
         else
         {
            automat.bestellungAufnehmen();
            automat.kassieren();
            automat.ausschenken();
         }
      }
   }
}
