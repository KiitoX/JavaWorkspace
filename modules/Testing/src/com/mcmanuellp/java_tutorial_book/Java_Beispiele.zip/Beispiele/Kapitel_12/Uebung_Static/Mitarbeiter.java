public class Mitarbeiter
{
   private String name;
   private int gehalt;
   private static int weihnachtsgeld = 0;
   
   public Mitarbeiter(String name, int gehalt)
   {
      this.name = name;

      if (gehalt <= 400)  
         this.gehalt = 400;
      else
         this.gehalt  = gehalt;
   }

   // nicht-statische Memberfunktionen
   public int getJahresverdienst()                     
   { 
      return 12 * gehalt + weihnachtsgeld; 
   }
   // ...
   
   // statische Memberfunktionen
   public static int getWeihnachtsgeld()   
   { 
      return weihnachtsgeld; 
   }
   public static void setWeihnachtsgeld(int betrag)    
   { 
      if (betrag >= 0)  
         weihnachtsgeld = betrag; 
   }
}
