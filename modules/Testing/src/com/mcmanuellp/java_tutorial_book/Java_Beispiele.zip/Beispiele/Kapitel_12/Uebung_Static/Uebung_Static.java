class Uebung_Static
{
   public static void main(String[] args)
   {
      System.out.println(Mitarbeiter.getWeihnachtsgeld());
      
      Mitarbeiter jeff = new Mitarbeiter("Jeff", 1800);
      System.out.println(jeff.getJahresverdienst());

      
      Mitarbeiter.setWeihnachtsgeld(1000);
      System.out.println(Mitarbeiter.getWeihnachtsgeld());
      System.out.println(jeff.getJahresverdienst());
      
      Mitarbeiter.setWeihnachtsgeld(-700);
      System.out.println(Mitarbeiter.getWeihnachtsgeld());
   }
}
