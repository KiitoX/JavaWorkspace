import java.util.Scanner;

class Programm
{
   public static void main(String[] args)
   {
     Vektor vekt1 = new Vektor();       // Vektor mit dem gerechnet wird
     Vektor vekt2 = new Vektor();       // zweiter Vektor f�r Addition,
                                        // Subtraktion, Vektorprodukt
     double x, y;                       // Zum Neusetzen des Vektors
     double betrag;                     // Ergebnis f�r Vektorprodukt und L-nge
    
     // Menue ausgeben
     int befehl = -1;

     while(befehl != 0)
     {
       System.out.println();
       System.out.println(" Menue ");
       System.out.println("  Vektoren eingeben       <1>");
       System.out.println("  Vektoren addieren       <2>");
       System.out.println("  Vektoren subtrahieren   <3>");
       System.out.println("  Laenge berechnen        <4>");
       System.out.println("  Programm beenden        <0>");

       System.out.println();
       System.out.print(" Ihre Eingabe : ");
       Scanner sc = new Scanner(System.in);
       befehl = sc.nextInt();  

       // Befehl bearbeiten
       switch(befehl)
       {
          case 0: System.out.println();
                  System.out.println("Programm beenden");
                  break;
          case 1: System.out.println();
                  System.out.println("Vektor eingeben");

                  // 1. Vektor einlesen
                  System.out.println();
                  System.out.print("    x : ");
                  x = sc.nextDouble();
                  System.out.print("    y : ");
                  y = sc.nextDouble();
                  System.out.println();

                  vekt1.setX(x);
                  vekt1.setY(y);
                  break;
          case 2: System.out.println();
                  System.out.println("Vektoren addieren");

                  // 2. Vektor einlesen
                  System.out.println("2. Vektor eingeben");
                  System.out.print("    x : ");
                  x = sc.nextDouble();
                  System.out.print("    y : ");
                  y = sc.nextDouble();
                  System.out.println();

                  vekt2.setX(x);
                  vekt2.setY(y);

                  // alten Wert ausgeben
                  System.out.print(vekt1);

                  // Vektoren addieren
                  vekt1.addieren(vekt2);

                  // Rest der Ausgabe
                  System.out.print(" + ");
                  System.out.print(vekt2);
                  System.out.print(" = ");
                  System.out.print(vekt1);
                  System.out.println();
                  break;
          case 3: System.out.println();
                  System.out.println("Vektoren subtrahieren");

                  // 2. Vektor einlesen
                  System.out.println("2. Vektor eingeben");
                  System.out.print("    x : ");
                  x = sc.nextDouble();
                  System.out.print("    y : ");
                  y = sc.nextDouble();
                  System.out.println();

                  vekt2.setX(x);
                  vekt2.setY(y);

                  // alten Wert ausgeben
                  System.out.print(vekt1);

                  // Vektoren subtrahieren
                  vekt1.subtrahieren(vekt2);

                  // Rest der Ausgabe
                  System.out.print(" - ");
                  System.out.print(vekt2);
                  System.out.print(" = ");
                  System.out.print(vekt1);
                  System.out.println();
                  break;
          case 4: System.out.println();
                  System.out.print("Laenge des Vektors ");

                  // Ergebnis ausgeben
                  System.out.println(vekt1);
                  System.out.println();
                  System.out.print("   : " + vekt1.laenge());
                  System.out.println(" Einheiten");
                  break;
         default: System.out.println();
                  System.out.println("Ungueltige Eingabe");
                  break;
       } // ende von switch

     } // ende von while
   }
}
