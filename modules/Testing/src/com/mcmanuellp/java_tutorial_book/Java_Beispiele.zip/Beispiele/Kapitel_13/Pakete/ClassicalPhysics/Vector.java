package ClassicalPhysics;

public class Vector
{         
   private int x;
   private int y;
   
   public Vector() 
   {
      x = 2;
      y = 2;
   }
   
   public String toString()
   {
      return new String( "(" + x + "," + y + ")" );
   }
}