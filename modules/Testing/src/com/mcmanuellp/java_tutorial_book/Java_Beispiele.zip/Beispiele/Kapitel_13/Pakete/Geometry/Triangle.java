package Geometry;

public class Triangle
{
}

