package Geometry;

public class Vector
{
   private int x;
   private int y;
   
   public Vector() 
   {
      x = 1;
      y = 1;
   }
   
   public String toString()
   {
      return new String( "(" + x + "," + y + ")" );
   }
}

