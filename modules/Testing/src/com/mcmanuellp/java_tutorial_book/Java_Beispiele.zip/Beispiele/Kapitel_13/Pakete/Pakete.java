// In deinem Code 

import Geometry.*;

class Pakete
{
   public static void main(String[] args)
   {
      Vector v1 = new Vector();
      System.out.println(v1);
      
      ClassicalPhysics.Vector v2 = new ClassicalPhysics.Vector();
      System.out.println(v2);
   }
}
