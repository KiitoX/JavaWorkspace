Um dieses Programm zu kompilieren, kannst du einen der folgenden Befehle

javac Pakete.java .\Geometry\Triangle.java .\Geometry\Vector.java .\ClassicalPhysics\Vector.java

oder

javac Pakete.java .\Geometry\*.java .\ClassicalPhysics\*.java

oder 

javac @dateien.txt

verwenden.



Zum Ausf�hren des Programms verwendest du einen der Befehle

java Pakete

oder

java -classpath .;.\Geometry;.\ClassicalPhysics Pakete