Um die Bibliothek zu erstellen, schicke von diesem Verzeichnis aus, die folgenden Befehle ab:

javac @dateien.txt

jar cf meinebib.jar ./utilities/*.class




Um die Anwendung zu erstellen, kopiere die jar-Bibliothek in das Verzeichnis anwendung, wechsle in das Verzeichnis anwendung und 

f�hre den folgenden Befehl aus

javac -cp .;.\meinebib.jar Programm.java




Zum Ausf�hren des Programms verwendest du den Befehl

java -cp .;.\meinebib.jar Programm