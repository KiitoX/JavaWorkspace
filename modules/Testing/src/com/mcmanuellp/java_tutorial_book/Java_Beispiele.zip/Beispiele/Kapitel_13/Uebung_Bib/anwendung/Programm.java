import utilities.Punkt;
import utilities.Vektor;

public class Programm
{
   public static void main(String[] args)
   {
      utilities.Punkt punkt = new Punkt(10,0);  
      System.out.println(" punkt: (" + punkt.x + "," + punkt.y + ")");

      System.out.println("\n Punkt: wird verschoben \n");
      punkt.verschieben(10, -10);
      
      System.out.println(" punkt: (" + punkt.x + "," + punkt.y + ")");
      System.out.println(" \n ");
      
      Vektor v1 = new Vektor(1,-1);
      System.out.println(" v1: " + v1);
      Vektor v2 = new Vektor(5,5);
      System.out.println(" v2: " + v2);
      
      System.out.println("\n Addiere v2 zu v1 \n");
      v1.addieren(v2);
      System.out.println(" v1: " + v1);
      

   }
}
