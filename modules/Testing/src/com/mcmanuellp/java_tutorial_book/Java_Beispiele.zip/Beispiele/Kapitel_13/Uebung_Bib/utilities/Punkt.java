package utilities;

/**
 * Die Klasse <code>Punkt</code> repr�sentiert Punkte in einem
 * zweidimensionalen Koordinatensystem.
 */ 
public class Punkt
{
   /**
    * Die x-Koordinate.
    */ 
   public int x;
   /**
    * Die x-Koordinate.
    */ 
   public int y;

   /**
    * Erzeugt einen Punkt am Ursprung (0,0).
    */ 
   public Punkt()              {  }

   /**
    * Erzeugt einen Punkt an den �bergebenen Koordinaten.
    */ 
   public Punkt(int n, int m)  { x = n;
                                 y = m; }   

   /**
    * Verschiebt den Punkt. Die Verschiebung erfolgt
    * relativ zur aktuellen Position.
    *             
    * @param   dx  Verschiebung entlang der x-Achse 
    * @param   dy  Verschiebung entlang der y-Achse 
    */ 
   public void verschieben(int dx, int dy) 
   {
      x += dx;
      y += dy; 
   }
}