class Demo 
{
   int wert = 1;

   int methode1() 
   {
      int wert = 2;  
                                   
      return wert;
   }

   void methode2() 
   {
      int j = 0;  
      int n = 1;                 
                                        
      for(int i = 1; i < 5; ++i) 
      {       
         n *= i;                        
      }                                 
                                        
      for(int i = 1; i < 5; ++i) 
      {       
         n -= i*i;                        
      }                                 

      // for(int j = 1; i < 5; ++i) 
      // {       
      //   n *= i;                        
      // }                                 
   }
}


class Verdeckung
{
   public static void main(String[] args) 
   {
      System.out.println();

      Demo obj = new Demo();

      System.out.println(" " + obj.wert);            // Ausgabe: 1
      System.out.println(" " + obj.methode1());      // Ausgabe: 2
      System.out.println(" " + obj.wert);            // Ausgabe: 1
   }  
}
