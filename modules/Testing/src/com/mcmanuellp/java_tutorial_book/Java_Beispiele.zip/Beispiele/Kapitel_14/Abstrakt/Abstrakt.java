class Feld { int x, y; }
enum Farbe { WEISS, SCHWARZ }

abstract class Figur 
{
   Farbe farbe;
   Feld feld;
   
   Figur(Farbe farbe, Feld feld)    { this.farbe = farbe; 
                                      this.feld = feld; }
   
   abstract int getWert(); 
   abstract boolean zugGueltig(final Feld f);
   
   final void ziehen(final Feld f)        { if (zugGueltig(f)) 
                                         feld = f; };
}


class Bauer extends Figur
{
   Bauer(Farbe farbe, Feld feld)      { super(farbe, feld); }
   int getWert()                      { return 1; }
   boolean zugGueltig(final Feld f)  
   { 
      System.out.println("Bauer"); 
      if (/* testen, ob Zug g�ltig */ true) return true;
      else return false;                            
   }
}

class Springer extends Figur
{
   Springer(Farbe farbe, Feld feld)   { super(farbe, feld); }
   int getWert()                      { return 3; };
   boolean zugGueltig(final Feld f)  
   { 
      System.out.println("Springer"); 
      if (/* testen, ob Zug g�ltig */ true) return true;
      else return false;  
   }
}



class Abstrakt
{
   public static void main(String[] args) 
   {
      Feld f = new Feld();
      Bauer bauer = new Bauer(Farbe.WEISS, f);
      Springer springer = new Springer(Farbe.SCHWARZ, f);
      
      bauer.ziehen(f);
      bauer.ziehen(f);
      springer.ziehen(f);
      bauer.ziehen(f);
      
      System.out.println("\n\n  Basisklassenvariable");
      Figur figur = bauer;
      figur.ziehen(f);
      figur = springer;
      figur.ziehen(f);
   }
}
