import java.util.*;

class Basis 
{
   String name;
   
   public Basis()                   { name = "Basis"; }
   public Basis(String name)        { this.name = name; }
   public void identifiziereDich()  { System.out.println(" Basis-Funktion " + name); }
   public void basisFunktion()      {}
}

class Abgeleitet extends Basis
{
   String name;
   
   public Abgeleitet()               { name = "Abgeleitet"; }
   public Abgeleitet(String name)    { super("BA"); this.name = name; }
   public void identifiziereDich()   { System.out.println(" Abgeleitet-Funktion " + name); }
   public void abgeleiteteFunktion() { System.out.println(name); }
}

public class AllgemeineLoesungen
{
   static void tueEtwas(Basis obj)
   {
      obj.basisFunktion();
      obj.identifiziereDich();
   }

   public static void main(String[] args) 
   {
      ArrayList<Basis> objekte = new ArrayList<Basis>();

      objekte.add(new Basis("jeff"));
      objekte.add(new Abgeleitet("magda"));
      objekte.add(new Abgeleitet("claudia"));
      objekte.add(new Basis("ruediger"));

      System.out.println("\n Objekte in ArrayList ausgeben\n");
      for (Basis obj : objekte)
         obj.identifiziereDich();
       
      System.out.println("\n" + " Objekte in ArrayList an tueEtwas() uebergeben \n");
      for (Basis obj : objekte)
          tueEtwas(obj);
   }
}
