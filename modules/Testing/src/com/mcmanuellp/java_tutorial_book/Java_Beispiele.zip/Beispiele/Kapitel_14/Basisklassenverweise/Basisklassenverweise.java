class Basis 
{
   String name;
   
   public Basis()                   { name = " Basis"; }
   public Basis(String name)        { this.name = name; }
   public void identifiziereDich()  { System.out.println(" Basis-Funktion " + name); }
   public void basisFunktion()      { System.out.println(name); }
}

class Abgeleitet extends Basis
{
   String name;
   
   public Abgeleitet()               { name = " Abgeleitet"; }
   public Abgeleitet(String name)    { super(" BA"); this.name = name; }
   public void identifiziereDich()   { System.out.println(" Abgeleitet-Funktion " + name); }
   public void abgeleiteteFunktion() { System.out.println(name); }
}

class Basisklassenverweise
{
   public static void main(String[] args) 
   {
      Basis b = new Basis();
      Abgeleitet a = new Abgeleitet();
      b.identifiziereDich();
      a.identifiziereDich();
      
      b = a;
      b.basisFunktion();
      //b.abgeleiteteFunktion();
      b.identifiziereDich();

      a = (Abgeleitet) b;
      a.basisFunktion();
      a.abgeleiteteFunktion();
      a.identifiziereDich();
   }
}
