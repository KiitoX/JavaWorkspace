public interface Inkrementierbar
{
   void inkrementieren();   
   void dekrementieren();   
}
