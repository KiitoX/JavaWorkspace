import java.util.ArrayList;

class Zaehler implements Inkrementierbar
{
   private int stand;    

   public Zaehler()                 { stand = 0; }
   public Zaehler(int startwert)    { stand = startwert; }
    
   public void zuruecksetzen()      { stand = 0; }    
   public int getStand()            { return stand; }
   
   public void inkrementieren()     { ++stand; }    
   public void dekrementieren()     { --stand; }    
}

class Note implements Inkrementierbar
{
   private int note;
   
   public Note(int note)            { this.note = note; }      
   public int getNote()             { return note; }
   public void inkrementieren()      
   { 
      if (note < 15)
         ++note;
   }    
   public void dekrementieren()        
   { 
      if (note > 1)
         --note;
   }   
}   


public class Programm
{
   public static void main(String[] args)
   {
      ArrayList<Inkrementierbar> container
                   = new ArrayList<Inkrementierbar>();
      
      container.add(new Zaehler(1));
      container.add(new Zaehler(234));
      container.add(new Note(12));
      container.add(new Note(15));
      
      for (Inkrementierbar obj : container)
      {
         obj.inkrementieren();
      }

      for (Inkrementierbar obj : container)
      {
         if (obj instanceof Zaehler)
            System.out.println(" Zaehlerstand: " 
                              + ((Zaehler) obj).getStand()); 
            
         else if (obj instanceof Note)
         {
            Note note = (Note) obj;
            System.out.println(" Note: " + note.getNote());
         }
      }
   }
}
