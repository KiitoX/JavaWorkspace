import basis.Basis;
import abgeleitet.Abgeleitet;

class ProtectedDemo
{
   public static void main(String[] args) 
   {
      Abgeleitet obj = new Abgeleitet();

      obj.vergroessern();
      // System.out.println(obj.wert);    // Fehler, da Member protected
      System.out.println(obj.getWert());  // okay
      
      obj.verkleinern();
      System.out.println(obj.getWert());
   }
}
