package abgeleitet;

public class Abgeleitet extends basis.Basis
{
   public Abgeleitet()        {}
   public void verkleinern()  { wert /= 10; }
}

