package basis;

public class Basis 
{
   protected int wert;
    
   public Basis()             { wert = 1; }
   public void vergroessern() { wert *= 10; }
   public int getWert()       { return wert; }
}
