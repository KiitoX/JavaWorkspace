class AlarmAnlage 
{
   AlarmAnlage()             {}
}

class AlarmAnlageStandard extends AlarmAnlage
{
   AlarmAnlageStandard()     {}
   void alarmSchlagen()      { System.out.println(" Alarm! "); }
}

class AlarmAnlageDeluxe extends AlarmAnlage
{
   AlarmAnlageDeluxe()          {}
   void alarmAusloesen()        { System.out.println(" Alarm! ");
                                  polizeiRufen();   }
                              
   private void polizeiRufen()  { System.out.println(" Polizei!"); }
}


class Ueberschreiben_v1
{
   public static void main(String[] args) 
   {
      AlarmAnlageStandard standard = new AlarmAnlageStandard();
      AlarmAnlageDeluxe deluxe = new AlarmAnlageDeluxe();
      
      System.out.println("\n Test der Standard-Version ");
      standard.alarmSchlagen();
      
      System.out.println("\n Test der Deluxe-Version ");
      deluxe.alarmAusloesen();
   }
}
