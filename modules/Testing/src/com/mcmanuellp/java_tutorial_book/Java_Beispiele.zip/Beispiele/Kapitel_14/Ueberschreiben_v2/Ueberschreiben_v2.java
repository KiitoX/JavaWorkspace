class AlarmAnlage 
{
   AlarmAnlage()            {}
   void alarmAusloesen()    { System.out.println(" Alarm! "); }
}

class AlarmAnlageStandard extends AlarmAnlage
{
   AlarmAnlageStandard()    {}
}

class AlarmAnlageDeluxe extends AlarmAnlage
{
   AlarmAnlageDeluxe()      {}
   void alarmAusloesen()    { System.out.println(" Alarm! ");
                              polizeiRufen();   }
                              
   void polizeiRufen()      { System.out.println(" Polizei!"); }
}


class Ueberschreiben_v2
{
   public static void main(String[] args) 
   {
      AlarmAnlageStandard standard = new AlarmAnlageStandard();
      AlarmAnlageDeluxe deluxe = new AlarmAnlageDeluxe();
      
      System.out.println("\n Test der Standard-Version mit Objekt");
      standard.alarmAusloesen();
      
      System.out.println("\n Test der Deluxe-Version mit Objekt");
      deluxe.alarmAusloesen();
      
      
      System.out.println("\n Test der Standard-Version mit Basisklassenverweis");
      AlarmAnlage p = standard;
      p.alarmAusloesen();
      
      System.out.println("\n Test der Deluxe-Version mit Basisklassenverweis");
      p = deluxe;
      p.alarmAusloesen();   
   }
}
