import java.util.*;

class Programm
{   
   public static void main(String[] args) 
   {
      System.out.println();

      ArrayList<Punkt> punkte = new ArrayList<Punkt>(6);

      punkte.add(new Punkt(0, 10));
      punkte.add(new Punkt(12, 10));
      punkte.add(new Punkt(-100, 10));
      punkte.add(new Punkt(0, 100));
      punkte.add(new Punkt(12, 10));
      punkte.add(new Punkt(0, 0));

      System.out.println(" Vor Sortierung:\n");
      for(Punkt p : punkte)
         System.out.println(" " + p.abstand());    

      Collections.sort(punkte); 

      System.out.println();
      System.out.println(" Nach Sortierung:\n");
      for(Punkt p : punkte)
         System.out.println(" " + p.abstand());    
   }   
}
