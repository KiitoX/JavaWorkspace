public class Punkt implements Comparable<Punkt> 
{
   public int x;
   public int y;

   public Punkt(int x, int y) 
   {
      this.x = x;
      this.y = y;
   }

   public double abstand() 
   {
      return Math.sqrt(x*x + y*y); 
   }
   
   public boolean equals(Object obj) 
   {
      if (obj == this)                      
         return true;  

      if (obj == null)                      
         return false;

      if (obj.getClass() != getClass() )    
         return false;

      Punkt p = (Punkt) obj;

      return ( (p.x == x) && (p.y == y) );
   }

   public int hashCode() 
   {
      long bits = Double.doubleToLongBits(x);
      bits ^= Double.doubleToLongBits(y) * 31;
      return (((int) bits) ^ ((int) (bits >> 32)));
   }

   public String toString() 
   {
      return new String("( " + x + " ; " + y + " )");
   }

   public final int compareTo(Punkt p) 
   {
      if (this.equals(p))
         return 0;
         
      else if ( this.abstand() - p.abstand() > 0.0)
         return 1;
      else
         return -1;
   }
}

