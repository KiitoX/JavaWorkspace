public class Angestellter extends Mitarbeiter
{
   public Angestellter(String name, int gehalt)    
   { 
      super(name, gehalt); 
   }   
   
   public void gehaltAendern(int betrag)           
   { 
      if ( gehalt + betrag > 0) 
         gehalt += betrag; 
   }
}
