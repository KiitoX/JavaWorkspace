public class Chef extends Mitarbeiter
{
   int bonus;

   public Chef(String name, int gehalt, int bonus)    
   { 
      super(name, gehalt); this.bonus = bonus; 
   }
   
   public int getBonus()                    { return gehalt; }
   public void setBonus(int betrag)                   
   { 
      if (betrag > 0) bonus = betrag; 
   }
   public void gehaltAendern(int betrag)              
   { 
      if ( betrag > 0 && gehalt + betrag >= 4000) 
         gehalt += betrag; 
   }
}
