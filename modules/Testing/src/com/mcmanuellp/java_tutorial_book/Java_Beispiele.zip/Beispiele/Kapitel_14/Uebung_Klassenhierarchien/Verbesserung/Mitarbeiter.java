public abstract class Mitarbeiter 
{
   private String name;
   protected int gehalt;
    
   public Mitarbeiter(String name, int gehalt)     
   { 
      this.name = name; 
      this.gehalt = gehalt; 
   }
   
   public String getName()                    { return name; }
   public int getGehalt()                     { return gehalt; }
   public abstract void gehaltAendern(int betrag);           
}
