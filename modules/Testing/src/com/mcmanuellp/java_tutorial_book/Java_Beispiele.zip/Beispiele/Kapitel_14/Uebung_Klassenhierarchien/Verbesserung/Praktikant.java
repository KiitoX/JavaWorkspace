public class Praktikant extends Mitarbeiter
{
   public Praktikant(String name, int gehalt)      
   { 
      super(name, gehalt); 
   }
   
   public void gehaltAendern(int betrag)           
   { 
      if (betrag + gehalt <= 430) 
         gehalt += betrag; 
   }
}
