class Programm
{
   public static void main(String[] args) 
   {
      Angestellter maria = new Angestellter("Maria", 2200);
      Praktikant kurt = new Praktikant("Kurt", 350);
      Chef itto = new Chef("Itto", 4500, 1000);

      System.out.println(maria.getName() + ": " + maria.getGehalt());
      System.out.println(kurt.getName() + ": " + kurt.getGehalt());
      System.out.println(itto.getName() + ": " + itto.getGehalt());
      
      System.out.println("\n" + " Gehalt aendern: 300, 50, 500 \n");
      
      maria.gehaltAendern(300);
      kurt.gehaltAendern(50);
      itto.gehaltAendern(500);
      
      System.out.println(maria.getName() + ": " + maria.getGehalt());
      System.out.println(kurt.getName() + ": " + kurt.getGehalt());
      System.out.println(itto.getName() + ": " + itto.getGehalt());
      
      System.out.println("\n" + " Gehalt aendern: -500, -3000, 50, -50, -5000 \n");
      maria.gehaltAendern(-500);
      System.out.println(maria.getName() + ": " + maria.getGehalt());
      maria.gehaltAendern(-3000);
      System.out.println(maria.getName() + ": " + maria.getGehalt());
      kurt.gehaltAendern(50);
      System.out.println(kurt.getName() + ": " + kurt.getGehalt());
      itto.gehaltAendern(-50);
      System.out.println(itto.getName() + ": " + itto.getGehalt());
      itto.gehaltAendern(-5000);
      System.out.println(itto.getName() + ": " + itto.getGehalt());
   }
}
