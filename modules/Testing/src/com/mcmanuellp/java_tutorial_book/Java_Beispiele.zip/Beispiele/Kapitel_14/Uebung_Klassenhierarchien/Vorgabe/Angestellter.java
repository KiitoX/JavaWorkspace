public class Angestellter 
{
   private String name;
   private int gehalt;

   public Angestellter(String name, int gehalt) 
   { 
      this.name = name;
      this.gehalt = gehalt;
   }   
   
   public String getName()                    { return name;}
   public int getGehalt()                     { return gehalt;}
   public void gehaltAendern(int betrag)        
   { 
      if(gehalt + betrag > 0) 
         gehalt += betrag;
   }
}
