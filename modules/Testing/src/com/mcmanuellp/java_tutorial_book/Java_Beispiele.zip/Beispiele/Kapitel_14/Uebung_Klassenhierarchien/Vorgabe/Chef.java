public class Chef 
{
   private String name;
   private int gehalt;
   private int bonus;

   public Chef(String name, int gehalt, int bonus) 
   {
      this.name = name; 
      this.gehalt = gehalt; 
      this.bonus = bonus; 
   }   
   
   public String getName()                      { return name;}
   public int getGehalt()                       { return gehalt;}
   public int getBonus()                        { return bonus;}
   public void setBonus(int betrag)             
   { 
      if (betrag > 0) 
         bonus = betrag; 
   }
   public void gehaltErhoehen(int betrag) 
   { 
      if ( betrag > 0 && gehalt + betrag >= 4000) 
          gehalt += betrag; 
   }
}
