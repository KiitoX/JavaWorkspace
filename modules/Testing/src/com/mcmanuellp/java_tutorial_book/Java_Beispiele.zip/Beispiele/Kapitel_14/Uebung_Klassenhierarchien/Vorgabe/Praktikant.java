public class Praktikant 
{
   private String name;
   private int lohn;
   
   public Praktikant(String name, int lohn)  
   { 
      this.name = name;
      this.lohn = lohn; 
   } 
   
   public String getName()                   { return name; }
   public int getLohn()                      { return lohn; }
   public void lohnAnpassen(int betrag)      
   { 
      if (betrag + lohn <= 430) 
         lohn += betrag; 
   }
}
