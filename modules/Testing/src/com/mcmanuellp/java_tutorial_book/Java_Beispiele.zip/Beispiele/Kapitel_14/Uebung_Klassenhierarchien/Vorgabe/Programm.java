class Programm
{
   public static void main(String[] args) 
   {
      System.out.println();
      
      Angestellter maria = new Angestellter("Maria", 2200);
      Praktikant kurt = new Praktikant("Kurt", 350);
      Chef itto = new Chef("Itto", 4500, 1000);

      System.out.println(maria.getName() + ": " + maria.getGehalt());
      System.out.println(kurt.getName() + ": " + kurt.getLohn());
      System.out.println(itto.getName() + ": " + itto.getGehalt());
      
      System.out.println("\n" + " Gehalt aendern: 300, 50, 500 \n");
      
      maria.gehaltAendern(300);
      kurt.lohnAnpassen(50);
      itto.gehaltErhoehen(500);

      System.out.println(maria.getName() + ": " + maria.getGehalt());
      System.out.println(kurt.getName() + ": " + kurt.getLohn());
      System.out.println(itto.getName() + ": " + itto.getGehalt());
   }
}
