import basis.Basis;
import abgeleitet.Abgeleitet;

class Unterobjekt
{
   public static void main(String[] args) 
   {
      Basis bObj = new Basis(7);
      Abgeleitet abgObj = new Abgeleitet();
      System.out.println(abgObj.getWert());

      bObj = abgObj;
      bObj.vergroessern();
      System.out.println(bObj.getWert());
      
      // bObj.verkleinern();      // Fehler
   }
}
