package abgeleitet;

public class Abgeleitet extends basis.Basis
{
   public Abgeleitet()        { super(1); }
   public void verkleinern()  { wert /= 10; }
}

