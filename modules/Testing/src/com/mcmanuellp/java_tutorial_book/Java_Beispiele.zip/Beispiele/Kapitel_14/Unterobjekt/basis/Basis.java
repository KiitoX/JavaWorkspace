package basis;

public class Basis 
{
   protected int wert;
    
   public Basis(int w)        { wert = w; }
   public void vergroessern() { wert *= 10; }
   public int getWert()       { return wert; }
}
