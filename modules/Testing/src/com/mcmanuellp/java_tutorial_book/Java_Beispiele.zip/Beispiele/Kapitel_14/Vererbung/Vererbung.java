class Basis 
{
   int wert;
    
   Basis()             { wert = 1; }
   void vergroessern() { wert *= 10; }
}

class Abgeleitet extends Basis
{
   Abgeleitet()        {}
   void verkleinern()  { wert /= 10; }
}


class Vererbung
{
   public static void main(String[] args) 
   {
      Abgeleitet obj = new Abgeleitet();

      obj.vergroessern();
      System.out.println(obj.wert);
      
      obj.verkleinern();
      System.out.println(obj.wert);
   }
}
