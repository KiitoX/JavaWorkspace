class Ausgabe
{
   public static void main(String[] args)
   {
     System.out.println();

     String name = "Georg";
     int alter = 87;
     System.out.printf(" Name, Alter \n");
     System.out.printf(" Name: %s, Alter \n", name);
     System.out.printf(" Name: %s, Alter: %d \n", name, alter);
     System.out.println();
     
     System.out.println("" + 123 + "|");          
     System.out.printf("%d|\n", 123);   
     System.out.println();
     System.out.printf("%+d|\n", 123);          
     System.out.printf("%5d|\n", 123);          
     System.out.printf("%-5d|\n", 123);          
     System.out.printf("%-5X|\n", 123);          
     System.out.println();
     System.out.printf("%.3f|\n", 12345.6789);          
     System.out.printf("%.3e|\n", 12345.6789);          
     System.out.println();
   }
}