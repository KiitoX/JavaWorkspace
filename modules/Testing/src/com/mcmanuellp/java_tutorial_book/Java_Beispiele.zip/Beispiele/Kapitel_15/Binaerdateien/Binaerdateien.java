import java.io.*;
import java.util.*;

class Binaerdateien
{
   public static void main(String[] args) 
                      throws IOException, FileNotFoundException
   {
      FileInputStream dat_ein;
      FileOutputStream dat_aus;

      // Schreiben
      dat_aus = new FileOutputStream("zahlen.dat");

      for (int i = 0; i < 10; i++)
         dat_aus.write(i); 

      dat_aus.close();

      // Lesen
      dat_ein = new FileInputStream("zahlen.dat");

      ArrayList<Integer> zahlen = new ArrayList<Integer>();
      int n;
      
      while ( (n = dat_ein.read()) != -1)
         zahlen.add(n);
      
      for (int zahl : zahlen)
         System.out.println(zahl);

      dat_ein.close();
   }
}
