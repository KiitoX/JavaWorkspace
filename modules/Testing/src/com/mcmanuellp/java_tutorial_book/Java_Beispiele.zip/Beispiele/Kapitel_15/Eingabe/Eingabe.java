import java.util.*;

class Eingabe
{
   public static void main(String[] args)
   {
      int eingabe = 0;

      Scanner sc = new Scanner(System.in);
      String s = null;

      System.out.print(" Geben Sie eine ganze Zahl ein: ");
      while (sc.hasNextInt() == false)
      {
         System.out.print(" Geben Sie eine ganze Zahl ein: ");
         sc.next();
      }
      eingabe = sc.nextInt();  

      System.out.println(" Eingabe: " + eingabe);
   }
}
