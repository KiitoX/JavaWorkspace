import java.util.*;
import java.util.regex.*;

class EingabeZeilen
{
   public static void main(String[] args)                   
   {    
      {
      String name = "";
      String vorname = "";
      String nachname = "";

      System.out.print(" Geben Sie Ihren Vor- und Nachnamen ein: ");   
      Scanner sc = new Scanner(System.in);
      name = sc.nextLine(); 

      vorname = name.substring(0, name.lastIndexOf(' '));
      nachname = name.substring(name.lastIndexOf(' ')+1);
      
      System.out.println(" Hallo " + vorname + " " + nachname);
      }
/*      
      {
      String name = "";
      String vorname = "";
      String nachname = "";

      System.out.print(" Geben Sie Ihren Vor- und Nachnamen ein: ");   
      Scanner sc = new Scanner(System.in);
      sc.findInLine("(\\w+) (\\w+)"); 
      MatchResult ergebnis = sc.match();
      if ( ergebnis.groupCount() >= 2)
      {
         vorname = ergebnis.group(1);
         nachname = ergebnis.group(2);
      }
      else
         System.out.println(" Falsche Eingabe ");

      System.out.println(" Hallo " + vorname + " " + nachname);         
      }
*/   
   }
}
