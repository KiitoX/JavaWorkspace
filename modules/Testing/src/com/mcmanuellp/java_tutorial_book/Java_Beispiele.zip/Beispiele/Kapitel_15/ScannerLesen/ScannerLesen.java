import java.io.*;
import java.util.*;

class ScannerLesen
{
   public static void main(String[] args) throws IOException
   {
      Scanner sc = new Scanner(new File("Urbanisierung.txt"));
      String wort;
      int zahl;

      while (sc.hasNext()) 
      {
         wort = sc.next();
         zahl  = sc.nextInt();
         sc.next();             // %-Zeichen einfach �berlesen
         // � weitere Verarbeitung
         
         System.out.println(wort + ": \t" + zahl + " %");
      }
      sc.close();
   }
}
