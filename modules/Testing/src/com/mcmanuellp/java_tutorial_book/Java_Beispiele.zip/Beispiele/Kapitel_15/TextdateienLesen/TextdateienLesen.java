import java.io.*;
import java.util.*;

class TextdateienLesen
{
   public static void main(String[] args) throws IOException
   {
      BufferedReader datei;
      String dateiname;

      System.out.print("Geben Sie den Namen der Datei ein: ");
      Scanner sc = new Scanner(System.in);
      dateiname = sc.next();   

      try
      {
         datei = new BufferedReader(new FileReader(dateiname));
      }
      catch(FileNotFoundException e)
      {
         System.err.println("Datei konnte nicht geoeffnet werden!");
         return;
      }

      ArrayList<String> zeilen = new ArrayList<String>();
      String s;
      
      while ( (s = datei.readLine()) != null)
      {
         zeilen.add(s);
      }
      
      for (String zeile : zeilen)
         System.out.println(zeile);
      
      datei.close();
   }
}
