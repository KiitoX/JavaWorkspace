import java.io.*;
import java.util.Scanner;

class TextdateienSchreiben
{
   public static void main(String[] args)
   {
      PrintWriter datei;
      String dateiname;

      System.out.print("Geben Sie den Namen der Datei ein: ");
      Scanner sc = new Scanner(System.in);
      dateiname = sc.next();   

      try
      {
         datei = new PrintWriter(dateiname);
      }
      catch(FileNotFoundException e)
      {
         System.err.println("Datei konnte nicht geoeffnet werden!");
         return;
      }

      datei.println(dateiname);
      datei.println("John Maynard!");
      datei.println("\"Wer ist John Maynard?\"");

      datei.close();
   }
}
