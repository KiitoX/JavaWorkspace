import java.io.*;
import java.util.*;

class Wertepaar 
{
   String name;
   double temperatur;
}

class WertepaarVergleicher implements Comparator<Wertepaar>
{
   public int compare(Wertepaar a, Wertepaar b)
   {
      Double d1 = new Double(a.temperatur);
      Double d2 = new Double(b.temperatur);
      
      return d1.compareTo(d2);
   }
}

class Uebung_Temperaturen
{
   public static void main(String[] args) throws IOException
   {
      BufferedReader datei;
      String dateiname;

      System.out.print("Geben Sie den Namen der Datei ein: ");
      Scanner sc = new Scanner(System.in);
      dateiname = sc.next();   

      try
      {
         datei = new BufferedReader(new FileReader(dateiname));
      }
      catch(FileNotFoundException e)
      {
         System.err.println("Datei konnte nicht geoeffnet werden!");
         return;
      }


      ArrayList<Wertepaar> werte = new ArrayList<Wertepaar>();
      Wertepaar wp;
      String s;

      while ( (s = datei.readLine()) != null)
      {
        if (s.length() == 0 || !(Character.isLetter(s.charAt(0))) ) continue;

        String[] teile = s.split("[,;]");
        wp = new Wertepaar();
        wp.name = teile[0].trim();
        wp.temperatur = Double.valueOf(teile[1].trim());
        werte.add(wp);
      }
      
      datei.close();
      
      for(Wertepaar wert : werte)
      {
         System.out.println(wert.name + ": " + wert.temperatur);
      }


      if (werte.size() != 12)
      {
         System.out.println(werte.size());
         System.out.println(" Es konnten keine 12 Werte eingelesen werden!");
         return;
      }

      wp = Collections.max(werte, new WertepaarVergleicher());
      
      System.out.println();
      System.out.println(" Im Durchschnitt am waermsten ist der "
           + wp.name + " mit "
           + wp.temperatur + " Grad.");
   }
}


