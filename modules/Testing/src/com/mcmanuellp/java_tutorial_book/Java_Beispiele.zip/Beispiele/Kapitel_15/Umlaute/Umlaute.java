import java.io.*;

class Umlaute
{
   public static void main(String[] args)                   
   {                           
      Console console = System.console();
      console.printf("\n Die deutschen Umlaute: \n");
      console.printf(" � � � � \n");
      console.printf("\n Klammeraffe und Eurozeichen: \n");
      console.printf(" @ � \n");
   }
}
