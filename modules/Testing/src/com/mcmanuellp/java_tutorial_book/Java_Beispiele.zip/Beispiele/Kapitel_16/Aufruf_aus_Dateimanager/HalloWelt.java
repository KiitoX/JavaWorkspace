import java.util.Scanner;

public class HalloWelt
{
   public static void main(String[] args)
   {
      String name;
      System.out.print("Geben Sie Ihren Namen ein: ");
      Scanner sc = new Scanner(System.in);
      name = sc.next();  
      System.out.println("Hallo " + name);

      // Beenden nur nach Aufforderung
      System.out.print("\n Zum Beenden Eingabe-Taste druecken. ");
      Scanner sc2 = new Scanner(System.in);
      sc2.nextLine();
   }
}
