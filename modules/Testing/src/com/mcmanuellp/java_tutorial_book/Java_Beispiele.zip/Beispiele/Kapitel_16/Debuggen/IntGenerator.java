import java.util.Random; 
  
/**
 * Generator f�r zuf�llige int-Zahlen. Seine Spezialit�t ist
 * das Zur�ckliefern zuf�lliger Zahlen aus einem vorgegebenen
 * Wertebereich.
 */
public class IntGenerator
{
   /**
    * Der eigentliche, intern verwendete Zufallsgenerator
    */
   private static Random generator = new Random(); 
   private IntGenerator() {}
   
   /**
    * Erzeugt eine zuf�llige ganze Zahl aus einem vorgegebenen 
    * Wertebereich. Der Wertebereich wird �ber die �bergebenen
    * Argumente definiert.
    * 
    * @param min   untere Grenze des Wertebereichs 
    * @param max   obere Grenze des Wertebereichs 
    * @return      ganze Zahl im Bereich [min,max]
    */ 
   public static int zufallszahl(int min, int max)
   {
      if (min > max)
      {
         int tmp = min;
         System.out.println("min  \t max  \t tmp  ");
         System.out.println(min + "\t " + max + "\t " + tmp);
         max = tmp;
         System.out.println(min + "\t " + max + "\t " + tmp);
         min = max;
         System.out.println(min + "\t " + max + "\t " + tmp);
      }
      
      return generator.nextInt(max-min+1) + min;
   }
}

class Debuggen
{
   public static void main(String[] args)
   {
      IntGenerator.zufallszahl(15,10);
   }
}
