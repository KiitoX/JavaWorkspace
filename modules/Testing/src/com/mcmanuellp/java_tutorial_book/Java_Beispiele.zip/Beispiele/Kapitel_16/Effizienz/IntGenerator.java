import java.util.Random; 
  
/**
 * Generator f�r zuf�llige int-Zahlen. Seine Spezialit�t ist
 * das Zur�ckliefern zuf�lliger Zahlen aus einem vorgegebenen
 * Wertebereich.
 */
public class IntGenerator
{
   /**
    * Der eigentliche, intern verwendete Zufallsgenerator
    */
   private static Random generator = new Random(); 
   private IntGenerator() {}
   
   /**
    * Erzeugt eine zuf�llige ganze Zahl aus einem vorgegebenen 
    * Wertebereich. Der Wertebereich wird �ber die �bergebenen
    * Argumente definiert.
    * 
    * @param min   untere Grenze des Wertebereichs 
    * @param max   obere Grenze des Wertebereichs 
    * @return      ganze Zahl im Bereich [min,max]
    */ 
   public static int zufallszahl(int min, int max)
   {
      if (min > max)
      {
         int tmp = min;
         min = max;
         max = tmp;
      }
      
      return generator.nextInt(max-min+1) + min;
   }
}


class Zeitmessung
{
   public static void main(String[] args)
   {
      long start, ende;
      long diff;
      double tmp;

      // Zeitnahme vor dem zu messenden Codeblock
      start = System.currentTimeMillis();

         // Block, dessen Ausf�hrungszeit gemessen werden soll
         // Berechnung von 10 Millionen Zufallszahlen
         for (int n = 0; n < 10000000; n++)
         {
            IntGenerator.zufallszahl(10,15);
         }


      // Zeitnahme nach dem zu messenden Codeblock
      ende = System.currentTimeMillis();

      // Auswertung
      diff = ende - start;

      System.out.println();
      System.out.println(" Benoetigte Zeit (in Millisekunden): " + diff);
      System.out.printf(" Benoetigte Zeit (in sec.) : %.2f", diff/1000.0);
      System.out.println();
   }
}
