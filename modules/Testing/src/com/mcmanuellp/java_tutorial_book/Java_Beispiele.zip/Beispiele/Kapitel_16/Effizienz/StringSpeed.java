import java.util.*;

public class StringSpeed 
{
   public static void main(String[] args) 
   {
      System.out.println();

      String a = "";
      String b = "Hallo"; 
      long start, ende; 

      // String-Version
      start = 0; ende = 0;
      start = System.currentTimeMillis();

      for(int i = 0; i < 10000; i++)
         a += b; 

      ende = System.currentTimeMillis();
      System.out.println(" String: " + (ende - start) + " ms");  
      
      
      // StringBuilder-Version
      a = "";
      b = "Hallo";
      StringBuilder sb = new StringBuilder(a);
      start = System.currentTimeMillis();

      for(int i = 0; i < 10000; i++)
         sb.append(b); 
 
      a = sb.toString();
      ende = System.currentTimeMillis();
      System.out.println(" StringBuilder: " + (ende - start) + " ms");  
   }
}
