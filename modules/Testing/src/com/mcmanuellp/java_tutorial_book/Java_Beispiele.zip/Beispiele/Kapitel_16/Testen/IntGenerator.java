import java.util.Random; 
  
/**
 * Generator f�r zuf�llige int-Zahlen. Seine Spezialit�t ist
 * das Zur�ckliefern zuf�lliger Zahlen aus einem vorgegebenen
 * Wertebereich.
 */
public class IntGenerator
{
   /**
    * Der eigentliche, intern verwendete Zufallsgenerator
    */
   private static Random generator = new Random(); 
   private IntGenerator() {}
   
   /**
    * Erzeugt eine zuf�llige ganze Zahl aus einem vorgegebenen 
    * Wertebereich. Der Wertebereich wird �ber die �bergebenen
    * Argumente definiert.
    * 
    * @param min   untere Grenze des Wertebereichs 
    * @param max   obere Grenze des Wertebereichs 
    * @return      ganze Zahl im Bereich [min,max]
    */ 
   public static int zufallszahl(int min, int max)
   {
      if (min > max)
      {
         int tmp = min;
         max = tmp;
         min = max;    
      }
      
      return generator.nextInt(max-min+1) + min;
   }
}

class IntGeneratorTest
{
   static void testeZufallszahl(int min, int max)
   {
      int n;
      boolean oben = false, unten = false;
      int korr_max = max;
      int korr_min = min;
      int diff = max - min + 1;

      if (min > max)
      {
         korr_max = min;
         korr_min = max;
         diff = min - max + 1;      
      }
      
      for (int i = 1; i < 10*diff; i++)
      {
         n = IntGenerator.zufallszahl(min, max);
         System.out.print(" " + n);
         if (n == korr_min) unten = true;
         if (n == korr_max) oben = true;
         
         // Test, ob Grenzen eingehalten
         if (n < korr_min || n > korr_max)
         {
            System.out.println(" Fehler, Grenzen ueberschritten ");
            return;
         }
      }   
         
      // Test, ob Grenzen eingehalten
      if (!oben || !unten)
      {
         System.out.println(" Fehler, Grenzen nicht erreicht ");
         return;
      }
      
      System.out.println();
   }

   public static void main(String[] args)
   {
      System.out.println("\n" + " zufallszahl(10,15)"); 
      testeZufallszahl(10,15);
      
      System.out.println("\n" + " zufallszahl(10,11)"); 
      testeZufallszahl(10,11);
      
      System.out.println("\n" + " zufallszahl(10,10)"); 
      testeZufallszahl(10,10);
      
      System.out.println("\n" + " zufallszahl(15,10)"); 
      testeZufallszahl(15,10);
      
      System.out.println("\n" + " zufallszahl(-5,5)"); 
      testeZufallszahl(-5,5);
   }
}
