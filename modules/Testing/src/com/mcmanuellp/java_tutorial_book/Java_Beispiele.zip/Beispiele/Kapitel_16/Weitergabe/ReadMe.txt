Eine Kurzreferenz zur vollst�ndigen Aufrufsyntax des jar-Tools erh�ltst du, wenn du in der Konsole einfach den Befehl

jar

abschickst.