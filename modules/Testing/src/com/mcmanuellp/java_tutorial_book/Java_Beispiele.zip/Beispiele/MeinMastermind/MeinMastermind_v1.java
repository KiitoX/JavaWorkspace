/**********************************
 * MeinMastermind_v1.java - das MeinMastermind-Programm
 *
 */
import java.util.Scanner;

public class MeinMastermind_v1
{
   public static void main(String[] args)
   {
      String stein1;     // Variablen f�r die Farbkombination, die sich das Programm ausdenkt
      String stein2;
      String stein3;
      String stein4;

      String geraten1;   // Variablen f�r die Farbkombination, die der Spieler r�t
      String geraten2;
      String geraten3;
      String geraten4;

      int trefferPosUndFarbe = 0;    // Variablen f�r die Treffer
      int trefferFarbe = 0;

      System.out.println(" ****************************** ");
      System.out.println(" Willkommen bei MeinMastermind! ");
      System.out.println();

      // zu ratende Kombination ausdenken
      stein1 = "weiss";
      stein2 = "rot";
      stein3 = "blau";
      stein4 = "blau";

      System.out.print( " Bitte eine Kombination aus"
                      + " vier Farben eingeben: ");
      Scanner sc = new Scanner(System.in);
      geraten1 = sc.next(); 
      geraten2 = sc.next(); 
      geraten3 = sc.next(); 
      geraten4 = sc.next(); 

      System.out.println(geraten1 + " " + geraten2 + " " 
                       + geraten3 + " " + geraten4);
   }
}
