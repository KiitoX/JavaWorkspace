/**********************************
 * MeinMastermind_v2.java - das MeinMastermind-Programm
 *
 */

import java.util.Scanner;
 
public class MeinMastermind_v2
{
   public static void main(String[] args)
   {
      String stein1;     // Variablen f�r die Farbkombination, die sich das Programm ausdenkt
      String stein2;
      String stein3;
      String stein4;

      String geraten1;   // Variablen f�r die Farbkombination, die der Spieler r�t
      String geraten2;
      String geraten3;
      String geraten4;

      int trefferPosUndFarbe = 0;    // Variablen f�r die Treffer
      int trefferFarbe = 0;

      System.out.println();
      System.out.println(" ****************************** ");
      System.out.println(" Willkommen bei MeinMastermind! \n");
      System.out.println(" Wir spielen mit 6 Farben: weiss, schwarz,"
                       + " blau, rot, gelb und gruen! \n\n\n");

      // zu ratende Kombination ausdenken
      stein1 = "weiss";
      stein2 = "rot";
      stein3 = "blau";
      stein4 = "blau";

      // lies den n�chsten Versuch des Spielers ein
      System.out.print( " Bitte eine Kombination aus"
                      + " vier Farben eingeben: \n\n");
      Scanner sc = new Scanner(System.in);
      geraten1 = sc.next(); 
      geraten2 = sc.next(); 
      geraten3 = sc.next(); 
      geraten4 = sc.next(); 
      
      boolean ausgewertetS1 = false, ausgewertetS2 = false, 
              ausgewertetS3 = false, ausgewertetS4 = false;

      boolean ausgewertetG1 = false, ausgewertetG2 = false, 
              ausgewertetG3 = false, ausgewertetG4 = false;
            
      if (stein1.equals(geraten1) == true)    // zuerst feststellen, welche Steine in Farbton und Position �bereinstimmen
      {
        trefferPosUndFarbe++;
        ausgewertetS1 = true;
        ausgewertetG1 = true;
      }

      if (stein2.equals(geraten2) == true)
      {
        trefferPosUndFarbe++;
        ausgewertetS2 = true;
        ausgewertetG2 = true;
      }

      if (stein3.equals(geraten3) == true)
      {
        trefferPosUndFarbe++;
        ausgewertetS3 = true;
        ausgewertetG3 = true;
      }

      if (stein4.equals(geraten4) == true)
      {
        trefferPosUndFarbe++;
        ausgewertetS4 = true;
        ausgewertetG4 = true;
      }

      if (ausgewertetS1 == false)   // dann feststellen, welche Steine nur im Farbton �bereinstimmen 
      {
        if (ausgewertetG2 == false && stein1.equals(geraten2) == true)
        {
          trefferFarbe++;
          ausgewertetS1 = true;
          ausgewertetG2 = true;
        }
        if (ausgewertetG3 == false && stein1.equals(geraten3) == true)
        {
          trefferFarbe++;
          ausgewertetS1 = true;
          ausgewertetG3 = true;
        }
        if (ausgewertetG4 == false && stein1.equals(geraten4) == true)
        {
          trefferFarbe++;
          ausgewertetS1 = true;
          ausgewertetG4 = true;
        }
      }

      if (ausgewertetS2 == false)
      {
        if (ausgewertetG1 == false && stein2.equals(geraten1) == true)
        {
          trefferFarbe++;
          ausgewertetS2 = true;
          ausgewertetG1 = true;
        }
        if (ausgewertetG3 == false && stein2.equals(geraten3) == true)
        {
          trefferFarbe++;
          ausgewertetS2 = true;
          ausgewertetG3 = true;
        }
        if (ausgewertetG4 == false && stein2.equals(geraten4) == true)
        {
          trefferFarbe++;
          ausgewertetS2 = true;
          ausgewertetG4 = true;
        }
      }

      if (ausgewertetS3 == false)
      {
        if (ausgewertetG1 == false && stein3.equals(geraten1) == true)
        {
          trefferFarbe++;
          ausgewertetS3 = true;
          ausgewertetG1 = true;
        }
        if (ausgewertetG2 == false && stein3.equals(geraten2) == true)
        {
          trefferFarbe++;
          ausgewertetS3 = true;
          ausgewertetG2 = true;
        }
        if (ausgewertetG4 == false && stein3.equals(geraten4) == true)
        {
          trefferFarbe++;
          ausgewertetS3 = true;
          ausgewertetG4 = true;
        }
      }

      if (ausgewertetS4 == false)
      {
        if (ausgewertetG1 == false && stein4.equals(geraten1) == true)
        {
          trefferFarbe++;
          ausgewertetS4 = true;
          ausgewertetG1 = true;
        }
        if (ausgewertetG2 == false && stein4.equals(geraten2) == true)
        {
          trefferFarbe++;
          ausgewertetS4 = true;
          ausgewertetG2 = true;
        }
        if (ausgewertetG3 == false && stein4.equals(geraten3) == true)
        {
          trefferFarbe++;
          ausgewertetS4 = true;
          ausgewertetG3 = true;
        }
      }

      // die Bewertung der Kombination ausgeben
      if (trefferPosUndFarbe == 4)
      {
        System.out.println("\n\n  Gratulation!!!" 
                        + " - du hast die Kombination erraten!\n");
      }
      else
      {
        System.out.println("\n"
          + " Treffer (Position und Farbe): " + trefferPosUndFarbe + "\n"
          + " Treffer          (nur Farbe): " + trefferFarbe + "\n\n");
      }
   }
}
