/**********************************
 * MeinMastermind_v3.java - das MeinMastermind-Programm
 *
 */
import java.util.Scanner;
import java.util.Random; 

public class MeinMastermind_v3
{
   public static void main(String[] args)
   {
      String stein1;
      String stein2;
      String stein3;
      String stein4;

      String geraten1;
      String geraten2;
      String geraten3;
      String geraten4;

      int trefferPosUndFarbe = 0;
      int trefferFarbe = 0;

      System.out.println();
      System.out.println(" ****************************** ");
      System.out.println(" Willkommen bei MeinMastermind! \n");
      System.out.println(" Wir spielen mit 6 Farben: weiss, schwarz,"
                       + " blau, rot, gelb und gruen! \n\n\n");

      // Zufallsgenerator aktivieren
      Random generator = new Random(1);  // (1) zum Debuggen

      // zu ratende Kombination ausdenken
      int n;

      n = generator.nextInt(6) + 1;
      switch(n)
      {
        case 1:   stein1 = "weiss";
                  break;
        case 2:   stein1 = "schwarz";
                  break;
        case 3:   stein1 = "blau";
                  break;
        case 4:   stein1 = "rot";
                  break;
        case 5:   stein1 = "gelb";
                  break;
        case 6:   stein1 = "gruen";
                  break;
        default:  stein1 = "";
      }

      n = generator.nextInt(6) + 1;   
      switch(n)
      {
        case 1:   stein2 = "weiss";
                  break;
        case 2:   stein2 = "schwarz";
                  break;
        case 3:   stein2 = "blau";
                  break;
        case 4:   stein2 = "rot";
                  break;
        case 5:   stein2 = "gelb";
                  break;
        case 6:   stein2 = "gruen";
                  break;
        default:  stein2 = "";
      }              

      n = generator.nextInt(6) + 1;   
      switch(n)
      {
        case 1:   stein3 = "weiss";
                  break;
        case 2:   stein3 = "schwarz";
                  break;
        case 3:   stein3 = "blau";
                  break;
        case 4:   stein3 = "rot";
                  break;
        case 5:   stein3 = "gelb";
                  break;
        case 6:   stein3 = "gruen";
                  break;
        default:  stein3 = "";
      }
      n = generator.nextInt(6) + 1;   
      switch(n)
      {
        case 1:   stein4 = "weiss";
                  break;
        case 2:   stein4 = "schwarz";
                  break;
        case 3:   stein4 = "blau";
                  break;
        case 4:   stein4 = "rot";
                  break;
        case 5:   stein4 = "gelb";
                  break;
        case 6:   stein4 = "gruen";
                  break;
        default:  stein4 = "";
      }

      //System.out.println(stein1 + " " + stein2 + " " + stein3 + " " + stein4);
      do
      {
         trefferPosUndFarbe = 0;
         trefferFarbe = 0;

         // lies den n�chsten Versuch des Spielers ein
         System.out.print( " Bitte eine Kombination aus"
                         + " vier Farben eingeben: \n\n");
                         
         Scanner sc = new Scanner(System.in);
         geraten1 = sc.next(); 
         geraten2 = sc.next(); 
         geraten3 = sc.next(); 
         geraten4 = sc.next(); 

         boolean ausgewertetS1 = false, ausgewertetS2 = false, 
                 ausgewertetS3 = false, ausgewertetS4 = false;

         boolean ausgewertetG1 = false, ausgewertetG2 = false, 
                 ausgewertetG3 = false, ausgewertetG4 = false;

         if (stein1.equals(geraten1) == true)    // zuerst feststellen, welche Steine in Farbton und Position �bereinstimmen
         {
           trefferPosUndFarbe++;
           ausgewertetS1 = true;
           ausgewertetG1 = true;
         }

         if (stein2.equals(geraten2) == true)
         {
           trefferPosUndFarbe++;
           ausgewertetS2 = true;
           ausgewertetG2 = true;
         }

         if (stein3.equals(geraten3) == true)
         {
           trefferPosUndFarbe++;
           ausgewertetS3 = true;
           ausgewertetG3 = true;
         }

         if (stein4.equals(geraten4) == true)
         {
           trefferPosUndFarbe++;
           ausgewertetS4 = true;
           ausgewertetG4 = true;
         }

         if (ausgewertetS1 == false)   // dann feststellen, welche Steine nur im Farbton �bereinstimmen 
         {
           if (ausgewertetG2 == false && stein1.equals(geraten2) == true)
           {
             trefferFarbe++;
             ausgewertetS1 = true;
             ausgewertetG2 = true;
           }
           if (ausgewertetG3 == false && stein1.equals(geraten3) == true)
           {
             trefferFarbe++;
             ausgewertetS1 = true;
             ausgewertetG3 = true;
           }
           if (ausgewertetG4 == false && stein1.equals(geraten4) == true)
           {
             trefferFarbe++;
             ausgewertetS1 = true;
             ausgewertetG4 = true;
           }
         }

         if (ausgewertetS2 == false)
         {
           if (ausgewertetG1 == false && stein2.equals(geraten1) == true)
           {
             trefferFarbe++;
             ausgewertetS2 = true;
             ausgewertetG1 = true;
           }
           if (ausgewertetG3 == false && stein2.equals(geraten3) == true)
           {
             trefferFarbe++;
             ausgewertetS2 = true;
             ausgewertetG3 = true;
           }
           if (ausgewertetG4 == false && stein2.equals(geraten4) == true)
           {
             trefferFarbe++;
             ausgewertetS2 = true;
             ausgewertetG4 = true;
           }
         }

         if (ausgewertetS3 == false)
         {
           if (ausgewertetG1 == false && stein3.equals(geraten1) == true)
           {
             trefferFarbe++;
             ausgewertetS3 = true;
             ausgewertetG1 = true;
           }
           if (ausgewertetG2 == false && stein3.equals(geraten2) == true)
           {
             trefferFarbe++;
             ausgewertetS3 = true;
             ausgewertetG2 = true;
           }
           if (ausgewertetG4 == false && stein3.equals(geraten4) == true)
           {
             trefferFarbe++;
             ausgewertetS3 = true;
             ausgewertetG4 = true;
           }
         }

         if (ausgewertetS4 == false)
         {
           if (ausgewertetG1 == false && stein4.equals(geraten1) == true)
           {
             trefferFarbe++;
             ausgewertetS4 = true;
             ausgewertetG1 = true;
           }
           if (ausgewertetG2 == false && stein4.equals(geraten2) == true)
           {
             trefferFarbe++;
             ausgewertetS4 = true;
             ausgewertetG2 = true;
           }
           if (ausgewertetG3 == false && stein4.equals(geraten3) == true)
           {
             trefferFarbe++;
             ausgewertetS4 = true;
             ausgewertetG3 = true;
           }
         }

         // die Bewertung der Kombination ausgeben
         if (trefferPosUndFarbe == 4)
         {
           System.out.println("\n\n  Gratulation!!!" 
                        + " - du hast die Kombination erraten!\n");
         }
         else
         {
           System.out.println("\n"
             + " Treffer (Position und Farbe): " + trefferPosUndFarbe + "\n"
             + " Treffer          (nur Farbe): " + trefferFarbe + "\n\n");
         }        
      } while (trefferPosUndFarbe < 4);

   }
}
