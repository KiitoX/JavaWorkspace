/**********************************
 * MeinMastermind_v4.java - das MeinMastermind-Programm
 *
 */
import java.util.Scanner;
import java.util.Random; 

public class MeinMastermind_v4
{
   public static void main(String[] args)
   {
      final int anzahlSteine = 4;
      String[] stein = new String[anzahlSteine];
      String[] geraten = new String[anzahlSteine];

      int trefferPosUndFarbe = 0;
      int trefferFarbe = 0;

      System.out.println();
      System.out.println(" ****************************** ");
      System.out.println(" Willkommen bei MeinMastermind! \n");
      System.out.println(" Wir spielen mit 6 Farben: weiss, schwarz,"
                       + " blau, rot, gelb und gruen! \n\n\n");

      // Zufallsgenerator aktivieren
      Random generator = new Random();  // (1) zum Debuggen

      // zu ratende Kombination ausdenken
      int n;

      for (int i = 0; i < stein.length; i++) 
      {
         n = generator.nextInt(6) + 1;
         switch(n)
         {
            case 1:  stein[i] = "weiss";
                     break;
            case 2:  stein[i] = "schwarz";
                     break;
            case 3:  stein[i] = "blau";
                     break;
            case 4:  stein[i] = "rot";
                     break;
            case 5:  stein[i] = "gelb";
                     break;
            case 6:  stein[i] = "gruen";
                     break;
            default: stein[i] = "";
         }
      }
      for (int i = 0; i < stein.length; i++) 
      {
         System.out.println(stein[i]);
      }

      do
      {
         trefferPosUndFarbe = 0;
         trefferFarbe = 0;

         // lies den n�chsten Versuch des Spielers ein
         System.out.print( " Bitte eine Kombination aus"
                         + " vier Farben eingeben: \n\n");
         Scanner sc = new Scanner(System.in);
         geraten[0] = sc.next(); 
         geraten[1] = sc.next(); 
         geraten[2] = sc.next(); 
         geraten[3] = sc.next(); 

         boolean[] ausgewertetS = {false, false, false, false};
         boolean[] ausgewertetG = {false, false, false, false};

         // zuerst feststellen, welche Steine in Farbton und Position �bereinstimmen
         for (int i = 0; i < stein.length; i++) 
         {
            if (stein[i].equals(geraten[i]) == true)    
            {
               trefferPosUndFarbe++;
               ausgewertetS[i] = true;
               ausgewertetG[i] = true;
            }
         }     

         // dann feststellen, welche Steine nur im Farbton �bereinstimmen
         for (int i = 0; i < stein.length; i++) 
         {
            if (ausgewertetS[i] == false)   
            {
               for (int j = 0; j < geraten.length; j++) 
               {
                  if (j == i)
                    continue;
                    
                  if (   ausgewertetG[j] == false 
                      && stein[i].equals(geraten[j]) == true)
                  {
                    trefferFarbe++;
                    ausgewertetS[i] = true;
                    ausgewertetG[j] = true;
                    break;
                  }
               }
            }
         }

         // die Bewertung der Kombination ausgeben
         if (trefferPosUndFarbe == 4)
         {
          System.out.println("\n\n Gratulation!!!" 
                            + " - du hast die Kombination erraten!\n");
         }
         else
         {
          System.out.println("\n"
            + " Treffer (Position und Farbe): " + trefferPosUndFarbe + "\n"
            + " Treffer          (nur Farbe): " + trefferFarbe + "\n\n");
         }
        
      } while (trefferPosUndFarbe < 4);
   }
}
