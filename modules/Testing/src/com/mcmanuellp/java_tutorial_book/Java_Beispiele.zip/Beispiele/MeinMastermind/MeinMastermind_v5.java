/**********************************
 * MeinMastermind_v5.java - das MeinMastermind-Programm
 *
 */
import java.util.Scanner;
import java.util.Random; 

class MeinMastermind_v5
{
   final static int anzahlSteine = 4;
   static String[] stein = new String[anzahlSteine];
   static String[] geraten = new String[anzahlSteine];

   static int trefferPosUndFarbe = 0;
   static int trefferFarbe = 0;
   
   /**
    * Liest eine Kombination aus vier Farben in das
    * Array geraten ein.
    */
   static void kombiEinlesen()
   {
      // lies den n�chsten Versuch des Spielers ein
      System.out.print( " Bitte eine Kombination aus"
                      + " vier Farben eingeben: \n\n");
      Scanner sc = new Scanner(System.in);
      geraten[0] = sc.next(); 
      geraten[1] = sc.next(); 
      geraten[2] = sc.next(); 
      geraten[3] = sc.next(); 
   }
   
   /**
    * Vergleicht die Farbkombination in geraten mit den Werten in
    * stein und h�lt die gefundenen Treffer in den Feldern
    * trefferPosUndFarbe und trefferFarbe fest.
    */
   static void kombiAuswerten()
   {
      boolean[] ausgewertetS = {false, false, false, false};
      boolean[] ausgewertetG = {false, false, false, false};

      // zuerst feststellen, welche Steine in Farbton und 
      // Position �bereinstimmen
      for (int i = 0; i < stein.length; i++) 
      {
         if (stein[i].equals(geraten[i]) == true)    
         {
            trefferPosUndFarbe++;
            ausgewertetS[i] = true;
            ausgewertetG[i] = true;
         }
      }     

      // dann feststellen, welche Steine nur im Farbton 
      // �bereinstimmen
      for (int i = 0; i < stein.length; i++) 
      {
         if (ausgewertetS[i] == false)   
         {
            for (int j = 0; j < geraten.length; j++) 
            {
               if (j == i)
                 continue;
                 
               if (   ausgewertetG[j] == false 
                   && stein[i].equals(geraten[j]) == true)
               {
                 trefferFarbe++;
                 ausgewertetS[i] = true;
                 ausgewertetG[j] = true;
                 break;
               }
            }
         }
      }
   }
   
   /**
    * Gibt eine Bewertung aus.
    */
   static void kombiBewerten()
   {
      // die Bewertung der Kombination ausgeben
      if (trefferPosUndFarbe == 4)
      {
       System.out.println("\n\n Gratulation!!!" 
                         + " - du hast die Kombination erraten!\n");
      }
      else
      {
       System.out.println("\n"
         + " Treffer (Position und Farbe): " + trefferPosUndFarbe + "\n"
         + " Treffer          (nur Farbe): " + trefferFarbe + "\n\n");
      }
   }
   
   public static void main(String[] args)
   {

      System.out.println();
      System.out.println(" ****************************** ");
      System.out.println(" Willkommen bei MeinMastermind! \n");
      System.out.println(" Wir spielen mit 6 Farben: weiss, schwarz,"
                       + " blau, rot, gelb und gruen! \n\n\n");

      // Zufallsgenerator aktivieren
      Random generator = new Random();  // (1) zum Debuggen

      // zu ratende Kombination ausdenken
      int n;

      for (int i = 0; i < stein.length; i++) 
      {
         n = generator.nextInt(6) + 1;
         switch(n)
         {
            case 1:  stein[i] = "weiss";
                     break;
            case 2:  stein[i] = "schwarz";
                     break;
            case 3:  stein[i] = "blau";
                     break;
            case 4:  stein[i] = "rot";
                     break;
            case 5:  stein[i] = "gelb";
                     break;
            case 6:  stein[i] = "gruen";
                     break;
            default: stein[i] = "";
         }
      }
      for (int i = 0; i < stein.length; i++) 
      {
         System.out.println(stein[i]);
      }

      do
      {
         trefferPosUndFarbe = 0;
         trefferFarbe = 0;

         // lies den n�chsten Versuch des Spielers ein
         kombiEinlesen();

         // die eingelesene Kombination mit der eigenen Kombination 
         // vergleichen
         kombiAuswerten();

         // die Bewertung der Kombination ausgeben
         kombiBewerten();

        
      } while (trefferPosUndFarbe < 4);
   }
}
