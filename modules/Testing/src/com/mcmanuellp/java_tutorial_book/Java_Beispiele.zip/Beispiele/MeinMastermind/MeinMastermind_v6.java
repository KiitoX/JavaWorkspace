/**********************************
 * MeinMastermind_v6.java - das MeinMastermind-Programm
 *
 */
import java.util.Scanner;
import java.util.Random; 

enum Farbe 
{
   WEISS, SCHWARZ, BLAU, ROT, GELB, GRUEN, UNBEKANNT;

   public static Farbe toFarbe(String s)
   {
      String[] farben = {"weiss", "schwarz", "blau", "rot", 
                         "gelb", "gruen", "unbekannt"};
      Farbe farbe = UNBEKANNT;
      int n = 0;
      
       for(Farbe f : values())
       {
          if (s.equals(farben[n]))
          {
            farbe = f;
          }
         
         n++;
       }
      
      return farbe;
   }   
   
   public static Farbe toFarbe(int n)
   {
      Farbe farbe = UNBEKANNT;
      
      switch (n)
      {
        case 1:   farbe = WEISS;
                  break;
        case 2:   farbe = SCHWARZ;
                  break;
        case 3:   farbe = BLAU;
                  break;
        case 4:   farbe = ROT;
                  break;
        case 5:   farbe = GELB;
                  break;
        case 6:   farbe = GRUEN;
                  break;
      }
      return farbe;
   }   
   
   public String toString()
   {
      String s = "";
      
      switch (this)
      {
        case WEISS:     s = "weiss";
                        break;
        case SCHWARZ:   s = "schwarz";
                        break;
        case BLAU:      s = "blau";
                        break;
        case ROT:       s = "rot";
                        break;
        case GELB:      s = "gelb";
                        break;
        case GRUEN:     s = "gruen";
                        break;
        default:        s = "unbekannte Farbe";
                        break;
      }

      return s;
   }
}

public class MeinMastermind_v6
{
   final static int anzahlSteine = 4;
   
   static Farbe[] stein = new Farbe[anzahlSteine];
   static Farbe[] geraten = new Farbe[anzahlSteine];

   static int trefferPosUndFarbe = 0;
   static int trefferFarbe = 0;

   /* Funktion zum Einlesen einer geratenen Kombination */
   static void kombiEinlesen()
   {
      // lies den n�chsten Versuch des Spielers ein
      System.out.print( " Bitte eine Kombination aus"
                      + " vier Farben eingeben: \n\n");
      Scanner sc = new Scanner(System.in);

      for (int i = 0; i < stein.length; i++) 
      {
         geraten[i] = Farbe.toFarbe(sc.next());
      }
      
      for (int i = 0; i < stein.length; i++) 
      {
         System.out.println(geraten[i] + " ");
      }
      System.out.println();
   }

   /* Funktion zum Auswerten einer eingelesenen Kombination */
   static void kombiAuswerten()
   {
      boolean[] ausgewertetS = {false, false, false, false};
      boolean[] ausgewertetG = {false, false, false, false};

      // zuerst feststellen, welche Steine in Farbton und Position �bereinstimmen
      for (int i = 0; i < stein.length; i++) 
      {
         if (stein[i].equals(geraten[i]) == true)    
         {
            trefferPosUndFarbe++;
            ausgewertetS[i] = true;
            ausgewertetG[i] = true;
         }
      }     

      // dann feststellen, welche Steine nur im Farbton �bereinstimmen
      for (int i = 0; i < stein.length; i++) 
      {
         if (ausgewertetS[i] == false)   
         {
            for (int j = 0; j < geraten.length; j++) 
            {
               if (j == i)
                 continue;
                 
               if (ausgewertetG[j] == false && stein[i].equals(geraten[j]) == true)
               {
                 trefferFarbe++;
                 ausgewertetS[i] = true;
                 ausgewertetG[j] = true;
                 break;
               }
            }
         }
      }
   }


   /* Funktion zum Bewerten einer geratenen Kombination */
   static void kombiBewerten()
   {
      // die Bewertung der Kombination ausgeben
      if (trefferPosUndFarbe == 4)
      {
         System.out.println("\n\n Gratulation!!!" 
                     + " - du hast die Kombination erraten!\n");
      }
      else
      {
         System.out.println("\n"
         + " Treffer (Position und Farbe): " + trefferPosUndFarbe + "\n"
         + " Treffer          (nur Farbe): " + trefferFarbe + "\n\n");
      }
   }

   public static void main(String[] args)
   {
      System.out.println();
      System.out.println(" ****************************** ");
      System.out.println(" Willkommen bei MeinMastermind! \n");
      System.out.println(" Wir spielen mit 6 Farben: weiss, schwarz,"
                       + " blau, rot, gelb und gruen! \n\n\n");

      // Zufallsgenerator aktivieren
      Random generator = new Random();  // (1) zum Debuggen

      // zu ratende Kombination ausdenken
      int n;

      for (int i = 0; i < stein.length; i++) 
      {
         stein[i] = Farbe.toFarbe(generator.nextInt(6) + 1);
      }
      for (int i = 0; i < stein.length; i++) 
      {
         System.out.println(stein[i]);
      }

      do
      {
         trefferPosUndFarbe = 0;
         trefferFarbe = 0;

         // lies den n�chsten Versuch des Spielers ein
         kombiEinlesen();

         // die eingelesene Kombination mit der eigenen Kombination vergleichen
         kombiAuswerten();

         // die Bewertung der Kombination ausgeben
         kombiBewerten();
        
      } while (trefferPosUndFarbe < 4);
   }
}
